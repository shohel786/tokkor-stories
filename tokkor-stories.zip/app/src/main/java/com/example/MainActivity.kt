package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.model.Story
import com.example.data.model.StoryCategory
import com.example.ui.components.LanguageSelectionSheet
import com.example.ui.components.StoryVoiceNarrationSheet
import com.example.ui.navigation.CategoriesRoute
import com.example.ui.navigation.FavoritesRoute
import com.example.ui.navigation.HomeRoute
import com.example.ui.navigation.PlayerRoute
import com.example.ui.navigation.SearchRoute
import com.example.ui.navigation.SettingsRoute
import com.example.ui.navigation.SplashRoute
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.VerticalPlayerScreen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.IvoryText
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RoyalIndigo
import com.example.ui.theme.SlateSilver
import com.example.ui.theme.TokkorGold
import com.example.ui.theme.TokkorStoriesTheme
import com.example.ui.viewmodel.PlaylistContext
import com.example.ui.viewmodel.TokkorViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.Transparent.toArgb()),
            navigationBarStyle = SystemBarStyle.dark(RoyalIndigo.toArgb())
        )
        setContent {
            TokkorStoriesTheme {
                TokkorStoriesApp()
            }
        }
    }
}

private data class TopLevelNavItem(
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val route: Any,
    val testTag: String
)

@Composable
fun TokkorStoriesApp(
    viewModel: TokkorViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    var showLanguageMenu by remember { mutableStateOf(false) }
    var voiceNarrationStory by remember { mutableStateOf<Story?>(null) }

    val topLevelItems = listOf(
        TopLevelNavItem(
            labelRes = R.string.nav_home,
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home,
            route = HomeRoute,
            testTag = "nav_home"
        ),
        TopLevelNavItem(
            labelRes = R.string.nav_categories,
            selectedIcon = Icons.Filled.GridView,
            unselectedIcon = Icons.Outlined.GridView,
            route = CategoriesRoute,
            testTag = "nav_categories"
        ),
        TopLevelNavItem(
            labelRes = R.string.nav_favorites,
            selectedIcon = Icons.Filled.Favorite,
            unselectedIcon = Icons.Outlined.FavoriteBorder,
            route = FavoritesRoute,
            testTag = "nav_favorites"
        ),
        TopLevelNavItem(
            labelRes = R.string.nav_settings,
            selectedIcon = Icons.Filled.Settings,
            unselectedIcon = Icons.Outlined.Settings,
            route = SettingsRoute,
            testTag = "nav_settings"
        )
    )

    val showNavigationChrome = currentDestination != null && (
        currentDestination.hasRoute<HomeRoute>() ||
            currentDestination.hasRoute<CategoriesRoute>() ||
            currentDestination.hasRoute<FavoritesRoute>() ||
            currentDestination.hasRoute<SettingsRoute>()
        )

    fun navigateTopLevel(route: Any) {
        navController.navigate(route) {
            popUpTo(HomeRoute) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun openPlayer(
        story: Story,
        playlistContext: PlaylistContext,
        category: StoryCategory?
    ) {
        navController.navigate(
            PlayerRoute(
                storyId = story.id,
                playlistContext = playlistContext.name,
                categoryName = category?.name
            )
        )
    }

    fun openVoiceSheetForStory(story: Story) {
        viewModel.prepareVoiceForStory(story)
        voiceNarrationStory = story
    }

    if (showLanguageMenu) {
        LanguageSelectionSheet(
            selectedLanguage = uiState.userSettings.selectedLanguage,
            otherSupportedLanguages = voiceState.otherSupportedLanguages,
            onSelectLanguage = viewModel::setLanguage,
            onDismiss = { showLanguageMenu = false }
        )
    }

    voiceNarrationStory?.let { activeStory ->
        StoryVoiceNarrationSheet(
            story = activeStory,
            voiceState = voiceState,
            onOpenLanguageMenu = { showLanguageMenu = true },
            onSelectVoiceGender = viewModel::setVoiceGender,
            onSpeedChange = viewModel::setVoiceSpeed,
            onPlayOrTogglePause = { viewModel.togglePlayPauseVoice(activeStory) },
            onStop = viewModel::stopVoice,
            onDismiss = { voiceNarrationStory = null }
        )
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = ObsidianBlack,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (showNavigationChrome && !useNavigationRail) {
                    NavigationBar(
                        containerColor = RoyalIndigo,
                        contentColor = IvoryText,
                        windowInsets = WindowInsets.navigationBars,
                        tonalElevation = 8.dp,
                        modifier = Modifier.testTag("bottom_navigation_bar")
                    ) {
                        topLevelItems.forEach { item ->
                            val selected = when (item.route) {
                                HomeRoute -> currentDestination?.hasRoute<HomeRoute>() == true
                                CategoriesRoute -> currentDestination?.hasRoute<CategoriesRoute>() == true
                                FavoritesRoute -> currentDestination?.hasRoute<FavoritesRoute>() == true
                                SettingsRoute -> currentDestination?.hasRoute<SettingsRoute>() == true
                                else -> false
                            }
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(item.labelRes),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ObsidianBlack,
                                    selectedTextColor = ChampagneGold,
                                    indicatorColor = TokkorGold,
                                    unselectedIconColor = SlateSilver,
                                    unselectedTextColor = SlateSilver
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showNavigationChrome && useNavigationRail) {
                    NavigationRail(
                        containerColor = RoyalIndigo,
                        contentColor = IvoryText,
                        modifier = Modifier
                            .fillMaxHeight()
                            .statusBarsPadding()
                            .testTag("navigation_rail")
                    ) {
                        topLevelItems.forEach { item ->
                            val selected = when (item.route) {
                                HomeRoute -> currentDestination?.hasRoute<HomeRoute>() == true
                                CategoriesRoute -> currentDestination?.hasRoute<CategoriesRoute>() == true
                                FavoritesRoute -> currentDestination?.hasRoute<FavoritesRoute>() == true
                                SettingsRoute -> currentDestination?.hasRoute<SettingsRoute>() == true
                                else -> false
                            }
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = stringResource(item.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(item.labelRes),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = ObsidianBlack,
                                    selectedTextColor = ChampagneGold,
                                    indicatorColor = TokkorGold,
                                    unselectedIconColor = SlateSilver,
                                    unselectedTextColor = SlateSilver
                                ),
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = SplashRoute,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<SplashRoute> {
                        SplashScreen(
                            onFinished = {
                                navController.navigate(HomeRoute) {
                                    popUpTo(SplashRoute) { inclusive = true }
                                    launchSingleTop = true
                                }
                            }
                        )
                    }

                    composable<HomeRoute> {
                        HomeScreen(
                            uiState = uiState,
                            onSearchClick = { navController.navigate(SearchRoute) },
                            onLanguageMenuClick = { showLanguageMenu = true },
                            onSeeAllCategoriesClick = { navigateTopLevel(CategoriesRoute) },
                            onSelectHomeCategory = viewModel::selectHomeCategory,
                            onPlayStory = ::openPlayer,
                            onListenStory = ::openVoiceSheetForStory,
                            onToggleFavorite = viewModel::toggleFavorite,
                            modifier = Modifier.statusBarsPadding()
                        )
                    }

                    composable<CategoriesRoute> {
                        CategoriesScreen(
                            uiState = uiState,
                            onSelectCategory = viewModel::selectCategoryScreenFilter,
                            onSearchClick = { navController.navigate(SearchRoute) },
                            onPlayStory = ::openPlayer,
                            onListenStory = ::openVoiceSheetForStory,
                            onToggleFavorite = viewModel::toggleFavorite,
                            modifier = Modifier.statusBarsPadding()
                        )
                    }

                    composable<FavoritesRoute> {
                        FavoritesScreen(
                            uiState = uiState,
                            onExploreStoriesClick = { navigateTopLevel(HomeRoute) },
                            onPlayStory = ::openPlayer,
                            onListenStory = ::openVoiceSheetForStory,
                            onToggleFavorite = viewModel::toggleFavorite,
                            modifier = Modifier.statusBarsPadding()
                        )
                    }

                    composable<SettingsRoute> {
                        SettingsScreen(
                            uiState = uiState,
                            onOpenLanguageMenu = { showLanguageMenu = true },
                            onVoiceGenderSelect = viewModel::setVoiceGender,
                            onVoiceSpeedChange = viewModel::setVoiceSpeed,
                            onAutoPlayNextChange = viewModel::setAutoPlayNext,
                            onStartMutedChange = viewModel::setStartMuted,
                            onLoopStoryChange = viewModel::setLoopStory,
                            onVideoQualitySelect = viewModel::setVideoQuality,
                            onClearFavoritesConfirm = viewModel::clearAllFavorites,
                            modifier = Modifier.statusBarsPadding()
                        )
                    }

                    composable<SearchRoute> {
                        SearchScreen(
                            uiState = uiState,
                            onBackClick = { navController.popBackStack() },
                            onQueryChange = viewModel::updateSearchQuery,
                            onQuickFilterSelect = viewModel::setSearchQuickFilter,
                            onCategoryFilterSelect = viewModel::setSearchCategoryFilter,
                            onClearFilters = viewModel::clearSearchFilters,
                            onPlayStory = ::openPlayer,
                            onListenStory = ::openVoiceSheetForStory,
                            onToggleFavorite = viewModel::toggleFavorite
                        )
                    }

                    composable<PlayerRoute> { backStackEntry ->
                        val route = backStackEntry.toRoute<PlayerRoute>()
                        val contextType = runCatching {
                            PlaylistContext.valueOf(route.playlistContext)
                        }.getOrDefault(PlaylistContext.ALL_STORIES)

                        val playlist = viewModel.resolvePlaylist(
                            contextType = contextType,
                            categoryName = route.categoryName
                        )

                        VerticalPlayerScreen(
                            stories = playlist,
                            initialStoryId = route.storyId,
                            favoriteIds = uiState.favoriteIds,
                            userSettings = uiState.userSettings,
                            voiceState = voiceState,
                            onOpenLanguageMenu = { showLanguageMenu = true },
                            onOpenVoiceSheet = ::openVoiceSheetForStory,
                            onPrepareVoiceForStory = viewModel::prepareVoiceForStory,
                            onStopVoiceOnClose = viewModel::stopVoice,
                            onToggleFavorite = viewModel::toggleFavorite,
                            onCloseClick = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
