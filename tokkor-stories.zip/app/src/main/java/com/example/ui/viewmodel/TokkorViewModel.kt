package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SettingsDataStore
import com.example.data.local.TokkorDatabase
import com.example.data.model.Story
import com.example.data.model.StoryCategory
import com.example.data.model.StoryLanguageOption
import com.example.data.model.UserSettings
import com.example.data.model.VideoQuality
import com.example.data.model.VoiceGender
import com.example.data.repository.StoryRepository
import com.example.data.voice.NarrationPlaybackState
import com.example.data.voice.VoiceNarrationManager
import com.example.data.voice.VoiceNarrationState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SearchQuickFilter {
    ALL,
    UNDER_45_SEC,
    FEATURED_ONLY
}

enum class PlaylistContext {
    ALL_STORIES,
    FEATURED,
    CATEGORY,
    FAVORITES,
    SEARCH_RESULTS
}

data class TokkorUiState(
    val allStories: List<Story> = emptyList(),
    val featuredStories: List<Story> = emptyList(),
    val selectedHomeCategory: StoryCategory? = null,
    val homeShorts: List<Story> = emptyList(),
    val selectedCategoryScreenFilter: StoryCategory? = null,
    val favoriteIds: Set<String> = emptySet(),
    val favoriteStories: List<Story> = emptyList(),
    val searchQuery: String = "",
    val searchQuickFilter: SearchQuickFilter = SearchQuickFilter.ALL,
    val searchSelectedCategory: StoryCategory? = null,
    val searchResults: List<Story> = emptyList(),
    val userSettings: UserSettings = UserSettings(),
    val firebaseReadyLabel: String = "Firebase Firestore (Ready)",
    val adMobReadyLabel: String = "Google AdMob (Ready)"
)

class TokkorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: StoryRepository by lazy {
        val db = TokkorDatabase.getInstance(application)
        val settings = SettingsDataStore(application)
        StoryRepository(
            favoriteStoryDao = db.favoriteStoryDao(),
            settingsDataStore = settings
        )
    }

    private val voiceManager: VoiceNarrationManager by lazy {
        VoiceNarrationManager(application)
    }

    val voiceState: StateFlow<VoiceNarrationState>
        get() = voiceManager.state

    private val selectedHomeCategory = MutableStateFlow<StoryCategory?>(null)
    private val selectedCategoryScreenFilter = MutableStateFlow<StoryCategory?>(null)
    private val searchQuery = MutableStateFlow("")
    private val searchQuickFilter = MutableStateFlow(SearchQuickFilter.ALL)
    private val searchSelectedCategory = MutableStateFlow<StoryCategory?>(null)

    private data class FilterInputs(
        val homeCat: StoryCategory?,
        val catScreenFilter: StoryCategory?,
        val query: String,
        val quickFilter: SearchQuickFilter,
        val searchCat: StoryCategory?
    )

    private val filterInputsFlow = combine(
        selectedHomeCategory,
        selectedCategoryScreenFilter,
        searchQuery,
        searchQuickFilter,
        searchSelectedCategory
    ) { homeCat, catScreenFilter, query, quickFilter, searchCat ->
        FilterInputs(homeCat, catScreenFilter, query, quickFilter, searchCat)
    }

    val uiState: StateFlow<TokkorUiState> = combine(
        repository.stories,
        repository.favoriteIds,
        repository.userSettings,
        filterInputsFlow
    ) { stories, favIdList, settings, filters ->
        val favSet = favIdList.toSet()
        val storyById = stories.associateBy { it.id }
        val favStories = favIdList.mapNotNull { storyById[it] }
        val featured = stories.filter { it.isFeatured }
        val homeShorts = if (filters.homeCat == null) {
            stories
        } else {
            stories.filter { it.category == filters.homeCat }
        }

        val normalizedQuery = filters.query.trim().lowercase()
        val selectedLang = settings.selectedLanguage
        val searchMatches = stories.filter { story ->
            val localized = com.example.data.sample.StoryLocalization.getLocalizedContent(story, selectedLang)
            val matchesQuery = normalizedQuery.isEmpty() ||
                story.title.lowercase().contains(normalizedQuery) ||
                story.author.lowercase().contains(normalizedQuery) ||
                story.category.displayName.lowercase().contains(normalizedQuery) ||
                story.moodTag.lowercase().contains(normalizedQuery) ||
                story.synopsis.lowercase().contains(normalizedQuery) ||
                localized.localizedTitle.lowercase().contains(normalizedQuery) ||
                localized.narrationScript.lowercase().contains(normalizedQuery)

            val matchesQuick = when (filters.quickFilter) {
                SearchQuickFilter.ALL -> true
                SearchQuickFilter.UNDER_45_SEC -> story.durationSeconds <= 45
                SearchQuickFilter.FEATURED_ONLY -> story.isFeatured
            }

            val matchesSearchCat = filters.searchCat == null || story.category == filters.searchCat

            matchesQuery && matchesQuick && matchesSearchCat
        }

        val (firebaseLabel, adMobLabel) = repository.integrationStatus

        TokkorUiState(
            allStories = stories,
            featuredStories = featured,
            selectedHomeCategory = filters.homeCat,
            homeShorts = homeShorts,
            selectedCategoryScreenFilter = filters.catScreenFilter,
            favoriteIds = favSet,
            favoriteStories = favStories,
            searchQuery = filters.query,
            searchQuickFilter = filters.quickFilter,
            searchSelectedCategory = filters.searchCat,
            searchResults = searchMatches,
            userSettings = settings,
            firebaseReadyLabel = firebaseLabel,
            adMobReadyLabel = adMobLabel
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = TokkorUiState()
    )

    init {
        viewModelScope.launch {
            repository.userSettings
                .distinctUntilChanged { old, new ->
                    old.selectedLanguageCode == new.selectedLanguageCode &&
                        old.voiceGender == new.voiceGender &&
                        old.voiceSpeed == new.voiceSpeed
                }
                .collect { settings ->
                    voiceManager.updatePreferences(
                        language = settings.selectedLanguage,
                        gender = settings.voiceGender,
                        speed = settings.voiceSpeed
                    )
                }
        }
    }

    fun selectHomeCategory(category: StoryCategory?) {
        selectedHomeCategory.value = if (selectedHomeCategory.value == category) null else category
    }

    fun selectCategoryScreenFilter(category: StoryCategory?) {
        selectedCategoryScreenFilter.value = category
    }

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setSearchQuickFilter(filter: SearchQuickFilter) {
        searchQuickFilter.value = if (searchQuickFilter.value == filter && filter != SearchQuickFilter.ALL) {
            SearchQuickFilter.ALL
        } else {
            filter
        }
    }

    fun setSearchCategoryFilter(category: StoryCategory?) {
        searchSelectedCategory.value = if (searchSelectedCategory.value == category) null else category
    }

    fun clearSearchFilters() {
        searchQuery.value = ""
        searchQuickFilter.value = SearchQuickFilter.ALL
        searchSelectedCategory.value = null
    }

    fun toggleFavorite(storyId: String) {
        viewModelScope.launch {
            val isCurrentlyFavorite = uiState.value.favoriteIds.contains(storyId)
            repository.toggleFavorite(storyId, isCurrentlyFavorite)
        }
    }

    fun clearAllFavorites() {
        viewModelScope.launch {
            repository.clearAllFavorites()
        }
    }

    fun setAutoPlayNext(enabled: Boolean) {
        viewModelScope.launch { repository.setAutoPlayNext(enabled) }
    }

    fun setStartMuted(muted: Boolean) {
        viewModelScope.launch { repository.setStartMuted(muted) }
    }

    fun setLoopStory(loop: Boolean) {
        viewModelScope.launch { repository.setLoopStory(loop) }
    }

    fun setVideoQuality(quality: VideoQuality) {
        viewModelScope.launch { repository.setVideoQuality(quality) }
    }

    fun setLanguage(language: StoryLanguageOption) {
        viewModelScope.launch {
            repository.setLanguage(language)
        }
    }

    fun setVoiceGender(gender: VoiceGender) {
        viewModelScope.launch {
            repository.setVoiceGender(gender)
        }
    }

    fun setVoiceSpeed(speed: Float) {
        viewModelScope.launch {
            repository.setVoiceSpeed(speed)
        }
    }

    fun prepareVoiceForStory(story: Story) {
        voiceManager.prepareStory(story)
    }

    fun playVoiceForStory(story: Story) {
        voiceManager.playStory(story)
    }

    fun togglePlayPauseVoice(story: Story) {
        val current = voiceState.value
        if (current.activeStoryId != story.id) {
            voiceManager.playStory(story)
            return
        }
        when (current.playbackState) {
            NarrationPlaybackState.PLAYING -> voiceManager.pause()
            NarrationPlaybackState.PAUSED,
            NarrationPlaybackState.COMPLETED -> voiceManager.resume()
            NarrationPlaybackState.IDLE,
            NarrationPlaybackState.ERROR -> voiceManager.playStory(story)
        }
    }

    fun pauseVoice() {
        voiceManager.pause()
    }

    fun resumeVoice() {
        voiceManager.resume()
    }

    fun stopVoice() {
        voiceManager.stop()
    }

    fun resolvePlaylist(
        contextType: PlaylistContext,
        categoryName: String?
    ): List<Story> {
        val state = uiState.value
        val resolved = when (contextType) {
            PlaylistContext.FEATURED -> state.featuredStories
            PlaylistContext.CATEGORY -> {
                val cat = categoryName?.let { name ->
                    runCatching { StoryCategory.valueOf(name) }.getOrNull()
                }
                if (cat != null) state.allStories.filter { it.category == cat } else state.allStories
            }
            PlaylistContext.FAVORITES -> state.favoriteStories
            PlaylistContext.SEARCH_RESULTS -> state.searchResults
            PlaylistContext.ALL_STORIES -> state.allStories
        }
        return resolved.ifEmpty { state.allStories }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.release()
    }
}
