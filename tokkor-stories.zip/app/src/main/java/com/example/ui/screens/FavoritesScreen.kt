package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Story
import com.example.data.model.StoryCategory
import com.example.ui.components.HorizontalStoryListCard
import com.example.ui.components.TokkorEmptyState
import com.example.ui.theme.IvoryText
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RoyalIndigo
import com.example.ui.theme.SlateSilver
import com.example.ui.theme.TokkorGold
import com.example.ui.theme.VelvetPurple
import com.example.ui.viewmodel.PlaylistContext
import com.example.ui.viewmodel.TokkorUiState

@Composable
fun FavoritesScreen(
    uiState: TokkorUiState,
    onExploreStoriesClick: () -> Unit,
    onPlayStory: (Story, PlaylistContext, StoryCategory?) -> Unit,
    onListenStory: (Story) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedLanguage = uiState.userSettings.selectedLanguage

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(VelvetPurple.copy(alpha = 0.55f), RoyalIndigo, ObsidianBlack)
                )
            )
            .testTag("favorites_screen")
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.favorites_screen_title),
                            style = MaterialTheme.typography.displaySmall,
                            color = IvoryText
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = stringResource(R.string.favorites_screen_subtitle),
                            style = MaterialTheme.typography.bodyMedium,
                            color = SlateSilver
                        )
                    }

                    if (uiState.favoriteStories.isNotEmpty()) {
                        Text(
                            text = "${uiState.favoriteStories.size} saved",
                            style = MaterialTheme.typography.labelMedium,
                            color = TokkorGold
                        )
                    }
                }
            }

            if (uiState.favoriteStories.isEmpty()) {
                item {
                    TokkorEmptyState(
                        icon = Icons.Outlined.FavoriteBorder,
                        title = stringResource(R.string.favorites_empty_title),
                        body = stringResource(R.string.favorites_empty_body),
                        ctaLabel = stringResource(R.string.favorites_explore_cta),
                        onCtaClick = onExploreStoriesClick
                    )
                }
            } else {
                items(uiState.favoriteStories, key = { it.id }) { story ->
                    HorizontalStoryListCard(
                        story = story,
                        selectedLanguage = selectedLanguage,
                        isFavorite = true,
                        onPlayClick = {
                            onPlayStory(story, PlaylistContext.FAVORITES, null)
                        },
                        onListenClick = { onListenStory(story) },
                        onToggleFavorite = { onToggleFavorite(story.id) }
                    )
                }
            }
        }
    }
}
