package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AdsClick
import androidx.compose.material.icons.outlined.CloudQueue
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.HighQuality
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Man
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Repeat
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.VolumeOff
import androidx.compose.material.icons.outlined.Woman
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.VideoQuality
import com.example.data.model.VoiceGender
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.ElevatedNavy
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavyStroke
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RoyalIndigo
import com.example.ui.theme.SlateSilver
import com.example.ui.theme.TokkorGold
import com.example.ui.theme.VelvetPurple
import com.example.ui.viewmodel.TokkorUiState
import java.util.Locale

@Composable
fun SettingsScreen(
    uiState: TokkorUiState,
    onOpenLanguageMenu: () -> Unit,
    onVoiceGenderSelect: (VoiceGender) -> Unit,
    onVoiceSpeedChange: (Float) -> Unit,
    onAutoPlayNextChange: (Boolean) -> Unit,
    onStartMutedChange: (Boolean) -> Unit,
    onLoopStoryChange: (Boolean) -> Unit,
    onVideoQualitySelect: (VideoQuality) -> Unit,
    onClearFavoritesConfirm: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showClearDialog by remember { mutableStateOf(false) }
    val selectedLanguage = uiState.userSettings.selectedLanguage

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            containerColor = DeepNavySurface,
            titleContentColor = IvoryText,
            textContentColor = SlateSilver,
            title = { Text(stringResource(R.string.settings_clear_dialog_title)) },
            text = { Text(stringResource(R.string.settings_clear_dialog_body)) },
            confirmButton = {
                Button(
                    onClick = {
                        onClearFavoritesConfirm()
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CrimsonRose,
                        contentColor = IvoryText
                    ),
                    modifier = Modifier.testTag("settings_confirm_clear_btn")
                ) {
                    Text(stringResource(R.string.settings_clear_confirm))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showClearDialog = false },
                    modifier = Modifier.testTag("settings_cancel_clear_btn")
                ) {
                    Text(stringResource(R.string.settings_cancel), color = ChampagneGold)
                }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(VelvetPurple.copy(alpha = 0.55f), RoyalIndigo, ObsidianBlack)
                )
            )
            .testTag("settings_screen"),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Column {
                Text(
                    text = stringResource(R.string.settings_screen_title),
                    style = MaterialTheme.typography.displaySmall,
                    color = IvoryText
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.settings_screen_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = SlateSilver
                )
            }
        }

        // Multilingual Voice System Card
        item {
            SettingsSectionCard(title = stringResource(R.string.settings_section_voice)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onOpenLanguageMenu)
                        .minimumInteractiveComponentSize()
                        .padding(vertical = 10.dp)
                        .testTag("settings_language_row"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SettingsIconBadge(icon = Icons.Outlined.Language)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.settings_language_title),
                            style = MaterialTheme.typography.titleSmall,
                            color = IvoryText
                        )
                        Text(
                            text = "${selectedLanguage.nativeName} (${selectedLanguage.englishName})",
                            style = MaterialTheme.typography.bodySmall,
                            color = ChampagneGold
                        )
                    }
                    Surface(
                        color = VelvetPurple,
                        shape = RoundedCornerShape(50.dp),
                        border = BorderStroke(1.dp, TokkorGold.copy(alpha = 0.65f))
                    ) {
                        Text(
                            text = stringResource(R.string.voice_change_language),
                            style = MaterialTheme.typography.labelMedium,
                            color = ChampagneGold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                HorizontalDivider(color = NavyStroke.copy(alpha = 0.6f))

                // Male / Female Narrator Voice
                Column(
                    modifier = Modifier.padding(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SettingsIconBadge(icon = Icons.Outlined.Woman)
                        Column {
                            Text(
                                text = stringResource(R.string.settings_voice_gender_title),
                                style = MaterialTheme.typography.titleSmall,
                                color = IvoryText
                            )
                            Text(
                                text = "Selected: ${uiState.userSettings.voiceGender.label}",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateSilver
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        VoiceGender.entries.forEach { gender ->
                            val selected = uiState.userSettings.voiceGender == gender
                            FilterChip(
                                selected = selected,
                                onClick = { onVoiceGenderSelect(gender) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (gender == VoiceGender.FEMALE) {
                                            Icons.Outlined.Woman
                                        } else {
                                            Icons.Outlined.Man
                                        },
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(
                                            if (gender == VoiceGender.FEMALE) {
                                                R.string.voice_gender_female
                                            } else {
                                                R.string.voice_gender_male
                                            }
                                        )
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = MidnightNavy,
                                    labelColor = SlateSilver,
                                    iconColor = ChampagneGold,
                                    selectedContainerColor = TokkorGold,
                                    selectedLabelColor = ObsidianBlack,
                                    selectedLeadingIconColor = ObsidianBlack
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selected,
                                    borderColor = NavyStroke,
                                    selectedBorderColor = ChampagneGold
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settings_voice_gender_${gender.name.lowercase()}")
                            )
                        }
                    }
                }

                HorizontalDivider(color = NavyStroke.copy(alpha = 0.6f))

                // Voice Speed Control
                Column(
                    modifier = Modifier.padding(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            SettingsIconBadge(icon = Icons.Outlined.Speed)
                            Text(
                                text = stringResource(R.string.settings_voice_speed_title),
                                style = MaterialTheme.typography.titleSmall,
                                color = IvoryText
                            )
                        }
                        Text(
                            text = String.format(Locale.US, "%.2fx", uiState.userSettings.voiceSpeed),
                            style = MaterialTheme.typography.labelLarge,
                            color = ChampagneGold
                        )
                    }

                    Slider(
                        value = uiState.userSettings.voiceSpeed,
                        onValueChange = onVoiceSpeedChange,
                        valueRange = 0.65f..1.65f,
                        colors = SliderDefaults.colors(
                            thumbColor = ChampagneGold,
                            activeTrackColor = TokkorGold,
                            inactiveTrackColor = NavyStroke
                        ),
                        modifier = Modifier.testTag("settings_voice_speed_slider")
                    )
                }
            }
        }

        // Playback Preferences Card
        item {
            SettingsSectionCard(title = stringResource(R.string.settings_section_playback)) {
                SettingsToggleRow(
                    icon = Icons.Outlined.PlayCircle,
                    title = stringResource(R.string.settings_autoplay_title),
                    subtitle = stringResource(R.string.settings_autoplay_subtitle),
                    checked = uiState.userSettings.autoPlayNext,
                    onCheckedChange = onAutoPlayNextChange,
                    testTag = "settings_autoplay_switch"
                )

                HorizontalDivider(color = NavyStroke.copy(alpha = 0.6f))

                SettingsToggleRow(
                    icon = Icons.Outlined.VolumeOff,
                    title = stringResource(R.string.settings_muted_title),
                    subtitle = stringResource(R.string.settings_muted_subtitle),
                    checked = uiState.userSettings.startMuted,
                    onCheckedChange = onStartMutedChange,
                    testTag = "settings_muted_switch"
                )

                HorizontalDivider(color = NavyStroke.copy(alpha = 0.6f))

                SettingsToggleRow(
                    icon = Icons.Outlined.Repeat,
                    title = stringResource(R.string.settings_loop_title),
                    subtitle = stringResource(R.string.settings_loop_subtitle),
                    checked = uiState.userSettings.loopStory,
                    onCheckedChange = onLoopStoryChange,
                    testTag = "settings_loop_switch"
                )

                HorizontalDivider(color = NavyStroke.copy(alpha = 0.6f))

                Column(
                    modifier = Modifier.padding(vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        SettingsIconBadge(icon = Icons.Outlined.HighQuality)
                        Column {
                            Text(
                                text = stringResource(R.string.settings_quality_title),
                                style = MaterialTheme.typography.titleSmall,
                                color = IvoryText
                            )
                            Text(
                                text = uiState.userSettings.videoQuality.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateSilver
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VideoQuality.entries.forEach { quality ->
                            val selected = uiState.userSettings.videoQuality == quality
                            FilterChip(
                                selected = selected,
                                onClick = { onVideoQualitySelect(quality) },
                                label = { Text(quality.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = MidnightNavy,
                                    labelColor = SlateSilver,
                                    selectedContainerColor = TokkorGold,
                                    selectedLabelColor = ObsidianBlack
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selected,
                                    borderColor = NavyStroke,
                                    selectedBorderColor = ChampagneGold
                                ),
                                modifier = Modifier.testTag("settings_quality_${quality.name.lowercase()}")
                            )
                        }
                    }
                }
            }
        }

        // Library & Storage Card
        item {
            SettingsSectionCard(title = stringResource(R.string.settings_section_library)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(
                            enabled = uiState.favoriteStories.isNotEmpty(),
                            onClick = { showClearDialog = true }
                        )
                        .minimumInteractiveComponentSize()
                        .padding(vertical = 10.dp)
                        .testTag("settings_clear_favorites_row"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    SettingsIconBadge(
                        icon = Icons.Outlined.DeleteOutline,
                        tint = if (uiState.favoriteStories.isNotEmpty()) CrimsonRose else SlateSilver
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.settings_clear_favorites_title),
                            style = MaterialTheme.typography.titleSmall,
                            color = if (uiState.favoriteStories.isNotEmpty()) IvoryText else SlateSilver
                        )
                        Text(
                            text = stringResource(R.string.settings_clear_favorites_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateSilver
                        )
                    }
                    Surface(
                        color = ElevatedNavy,
                        shape = RoundedCornerShape(50.dp),
                        border = BorderStroke(1.dp, NavyStroke)
                    ) {
                        Text(
                            text = "${uiState.favoriteStories.size}",
                            style = MaterialTheme.typography.labelMedium,
                            color = ChampagneGold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // Future Integration Readiness Card
        item {
            SettingsSectionCard(title = stringResource(R.string.settings_section_architecture)) {
                SettingsInfoRow(
                    icon = Icons.Outlined.CloudQueue,
                    title = stringResource(R.string.settings_firebase_status_title),
                    subtitle = stringResource(R.string.settings_firebase_status_subtitle),
                    badgeText = uiState.firebaseReadyLabel
                )

                HorizontalDivider(color = NavyStroke.copy(alpha = 0.6f))

                SettingsInfoRow(
                    icon = Icons.Outlined.AdsClick,
                    title = stringResource(R.string.settings_admob_status_title),
                    subtitle = stringResource(R.string.settings_admob_status_subtitle),
                    badgeText = uiState.adMobReadyLabel
                )
            }
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.settings_version_label),
                    style = MaterialTheme.typography.labelMedium,
                    color = SlateSilver
                )
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = ChampagneGold
        )
        Card(
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.dp, NavyStroke),
            colors = CardDefaults.cardColors(containerColor = DeepNavySurface)
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                content()
            }
        }
    }
}

@Composable
private fun SettingsToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SettingsIconBadge(icon = icon)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = IvoryText
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = SlateSilver
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ObsidianBlack,
                checkedTrackColor = TokkorGold,
                uncheckedThumbColor = SlateSilver,
                uncheckedTrackColor = MidnightNavy,
                uncheckedBorderColor = NavyStroke
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
private fun SettingsInfoRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badgeText: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SettingsIconBadge(icon = icon)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                color = IvoryText
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = SlateSilver
            )
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                color = MidnightNavy,
                shape = RoundedCornerShape(50.dp),
                border = BorderStroke(1.dp, TokkorGold.copy(alpha = 0.4f))
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall,
                    color = ChampagneGold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingsIconBadge(
    icon: ImageVector,
    tint: Color = ChampagneGold
) {
    Surface(
        modifier = Modifier.size(38.dp),
        shape = CircleShape,
        color = ElevatedNavy,
        border = BorderStroke(1.dp, NavyStroke)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(19.dp)
            )
        }
    }
}
