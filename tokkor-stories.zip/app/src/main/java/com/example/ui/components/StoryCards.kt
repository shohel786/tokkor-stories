package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.LocalFireDepartment
import androidx.compose.material.icons.outlined.NightsStay
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material.icons.outlined.RocketLaunch
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.PrimaryStoryLanguages
import com.example.data.model.Story
import com.example.data.model.StoryCategory
import com.example.data.model.StoryLanguageOption
import com.example.data.sample.StoryLocalization
import com.example.ui.theme.BurnishedGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.ElevatedNavy
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavyStroke
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateSilver
import com.example.ui.theme.TokkorGold
import com.example.ui.theme.VelvetPurple

fun categoryIcon(category: StoryCategory): ImageVector = when (category) {
    StoryCategory.MYSTERY -> Icons.Outlined.NightsStay
    StoryCategory.SCI_FI -> Icons.Outlined.RocketLaunch
    StoryCategory.ROMANCE -> Icons.Outlined.FavoriteBorder
    StoryCategory.THRILLER -> Icons.Outlined.LocalFireDepartment
    StoryCategory.FOLKLORE -> Icons.Outlined.Explore
    StoryCategory.DRAMA -> Icons.Outlined.Psychology
}

@Composable
fun FeaturedStoryHeroCard(
    story: Story,
    selectedLanguage: StoryLanguageOption = PrimaryStoryLanguages.ENGLISH,
    isFavorite: Boolean,
    onPlayClick: () -> Unit,
    onListenClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val localized = StoryLocalization.getLocalizedContent(story, selectedLanguage)
    val contentDir = if (selectedLanguage.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(276.dp)
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onPlayClick)
            .testTag("featured_story_card_${story.id}"),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(
            1.dp,
            Brush.linearGradient(listOf(TokkorGold.copy(alpha = 0.78f), VelvetPurple, NavyStroke))
        ),
        colors = CardDefaults.cardColors(containerColor = MidnightNavy),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = story.coverResId),
                contentDescription = localized.localizedTitle,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                VelvetPurple.copy(alpha = 0.34f),
                                MidnightNavy.copy(alpha = 0.56f),
                                ObsidianBlack.copy(alpha = 0.95f)
                            )
                        )
                    )
            )

            // Top row: Featured gold badge + Duration + Favorite toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = TokkorGold,
                        shape = RoundedCornerShape(50.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Star,
                                contentDescription = null,
                                tint = ObsidianBlack,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = stringResource(R.string.home_featured_badge),
                                style = MaterialTheme.typography.labelSmall,
                                color = ObsidianBlack,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    DurationBadge(formattedDuration = story.formattedDuration)
                }

                FavoriteIconButton(
                    isFavorite = isFavorite,
                    onClick = onToggleFavorite,
                    testTag = "featured_fav_${story.id}"
                )
            }

            // Bottom localized editorial details + Watch & Voice Listen CTA
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "${story.category.displayName.uppercase()} • ${story.author.uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = ChampagneGold
                )

                CompositionLocalProvider(LocalLayoutDirection provides contentDir) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = localized.localizedTitle,
                            style = MaterialTheme.typography.headlineSmall,
                            color = IvoryText,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        Text(
                            text = localized.narrationScript,
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateSilver,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onListenClick,
                        border = BorderStroke(1.dp, TokkorGold.copy(alpha = 0.7f)),
                        shape = RoundedCornerShape(50.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("featured_listen_btn_${story.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.RecordVoiceOver,
                            contentDescription = null,
                            tint = ChampagneGold,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.home_listen_story),
                            style = MaterialTheme.typography.labelLarge,
                            color = IvoryText
                        )
                    }

                    Button(
                        onClick = onPlayClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TokkorGold,
                            contentColor = ObsidianBlack
                        ),
                        shape = RoundedCornerShape(50.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                            .testTag("featured_watch_btn_${story.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.home_watch_now),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VerticalStoryReelCard(
    story: Story,
    selectedLanguage: StoryLanguageOption = PrimaryStoryLanguages.ENGLISH,
    isFavorite: Boolean,
    onPlayClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val localized = StoryLocalization.getLocalizedContent(story, selectedLanguage)
    val contentDir = if (selectedLanguage.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onPlayClick)
            .testTag("story_card_${story.id}"),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, NavyStroke.copy(alpha = 0.85f)),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.78f)
            ) {
                Image(
                    painter = painterResource(id = story.coverResId),
                    contentDescription = localized.localizedTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(story.accentHex).copy(alpha = 0.14f),
                                    VelvetPurple.copy(alpha = 0.32f),
                                    ObsidianBlack.copy(alpha = 0.92f)
                                )
                            )
                        )
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DurationBadge(formattedDuration = story.formattedDuration)

                    FavoriteIconButton(
                        isFavorite = isFavorite,
                        onClick = onToggleFavorite,
                        testTag = "story_fav_${story.id}"
                    )
                }

                // Centered purple-gold play circle
                Surface(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(46.dp),
                    shape = CircleShape,
                    color = VelvetPurple.copy(alpha = 0.85f),
                    border = BorderStroke(1.5.dp, ChampagneGold.copy(alpha = 0.9f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.PlayArrow,
                            contentDescription = stringResource(R.string.player_play_cd),
                            tint = ChampagneGold,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(10.dp),
                    color = MidnightNavy.copy(alpha = 0.88f),
                    shape = RoundedCornerShape(50.dp),
                    border = BorderStroke(0.75.dp, BurnishedGold.copy(alpha = 0.55f))
                ) {
                    Text(
                        text = story.category.displayName.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = ChampagneGold,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                    )
                }
            }

            CompositionLocalProvider(LocalLayoutDirection provides contentDir) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = localized.localizedTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = IvoryText,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = story.author,
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateSilver,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun HorizontalStoryListCard(
    story: Story,
    selectedLanguage: StoryLanguageOption = PrimaryStoryLanguages.ENGLISH,
    isFavorite: Boolean,
    onPlayClick: () -> Unit,
    onListenClick: (() -> Unit)? = null,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val localized = StoryLocalization.getLocalizedContent(story, selectedLanguage)
    val contentDir = if (selectedLanguage.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onPlayClick)
            .testTag("story_row_${story.id}"),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, NavyStroke),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(width = 82.dp, height = 96.dp)
                    .clip(RoundedCornerShape(14.dp))
            ) {
                Image(
                    painter = painterResource(id = story.coverResId),
                    contentDescription = localized.localizedTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(VelvetPurple.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = CircleShape,
                        color = ObsidianBlack.copy(alpha = 0.78f),
                        border = BorderStroke(1.dp, TokkorGold),
                        modifier = Modifier.size(34.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.PlayArrow,
                                contentDescription = null,
                                tint = ChampagneGold,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = story.category.displayName.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = ChampagneGold
                    )
                    Text(
                        text = "• ${story.formattedDuration}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateSilver
                    )
                }

                CompositionLocalProvider(LocalLayoutDirection provides contentDir) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = localized.localizedTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = IvoryText,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Text(
                            text = localized.narrationScript,
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateSilver,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Text(
                    text = story.author,
                    style = MaterialTheme.typography.labelMedium,
                    color = TokkorGold
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                FavoriteIconButton(
                    isFavorite = isFavorite,
                    onClick = onToggleFavorite,
                    testTag = "row_fav_${story.id}"
                )
                if (onListenClick != null) {
                    IconButton(
                        onClick = onListenClick,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("row_listen_${story.id}")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(VelvetPurple.copy(alpha = 0.8f))
                                .border(1.dp, TokkorGold.copy(alpha = 0.65f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.RecordVoiceOver,
                                contentDescription = stringResource(R.string.home_listen_story),
                                tint = ChampagneGold,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DurationBadge(formattedDuration: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        color = ObsidianBlack.copy(alpha = 0.78f),
        shape = RoundedCornerShape(50.dp),
        border = BorderStroke(0.75.dp, NavyStroke)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.Schedule,
                contentDescription = null,
                tint = ChampagneGold,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = formattedDuration,
                style = MaterialTheme.typography.labelSmall,
                color = IvoryText
            )
        }
    }
}

@Composable
fun FavoriteIconButton(
    isFavorite: Boolean,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(48.dp)
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(ObsidianBlack.copy(alpha = 0.68f))
                .border(
                    width = 1.dp,
                    color = if (isFavorite) CrimsonRose.copy(alpha = 0.8f) else NavyStroke,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = stringResource(
                    if (isFavorite) R.string.favorites_toggle_remove_cd else R.string.favorites_toggle_add_cd
                ),
                tint = if (isFavorite) CrimsonRose else IvoryText,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun TokkorEmptyState(
    icon: ImageVector = Icons.Outlined.AutoStories,
    title: String,
    body: String,
    ctaLabel: String? = null,
    onCtaClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 32.dp, vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Surface(
            modifier = Modifier.size(76.dp),
            shape = CircleShape,
            color = ElevatedNavy,
            border = BorderStroke(1.dp, TokkorGold.copy(alpha = 0.55f))
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = ChampagneGold,
                    modifier = Modifier.size(34.dp)
                )
            }
        }

        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            color = IvoryText
        )

        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = SlateSilver,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        if (ctaLabel != null && onCtaClick != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Button(
                onClick = onCtaClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = TokkorGold,
                    contentColor = ObsidianBlack
                ),
                shape = RoundedCornerShape(50.dp),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("empty_state_cta_button")
            ) {
                Text(
                    text = ctaLabel,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}
