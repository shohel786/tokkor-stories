package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Obsidian, Dark Purple, Navy Blue, and Golden Palette for Tokkor Stories
val ObsidianBlack = Color(0xFF06080D)
val DeepObsidian = Color(0xFF0A0917)
val RoyalIndigo = Color(0xFF0F0D23)
val MidnightNavy = Color(0xFF0B1530)
val VelvetPurple = Color(0xFF1C133D)
val TwilightViolet = Color(0xFF2D1E5F)
val DeepNavySurface = Color(0xFF121A38)
val ElevatedNavy = Color(0xFF1B244B)
val NavyStroke = Color(0xFF2F3466)

val TokkorGold = Color(0xFFD4AF37)
val ChampagneGold = Color(0xFFF3D578)
val BurnishedGold = Color(0xFF9E7B22)
val SoftGoldGlow = Color(0x2AD4AF37)

val IvoryText = Color(0xFFF5F2EB)
val SlateSilver = Color(0xFFA9B1CC)
val MutedNavyText = Color(0xFF7B84A8)
val CrimsonRose = Color(0xFFE05A6D)
val EmeraldStream = Color(0xFF4CC38A)
