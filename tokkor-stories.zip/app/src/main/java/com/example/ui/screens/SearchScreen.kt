package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Story
import com.example.data.model.StoryCategory
import com.example.ui.components.HorizontalStoryListCard
import com.example.ui.components.TokkorEmptyState
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.IvoryText
import com.example.ui.theme.NavyStroke
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RoyalIndigo
import com.example.ui.theme.SlateSilver
import com.example.ui.theme.TokkorGold
import com.example.ui.theme.VelvetPurple
import com.example.ui.viewmodel.PlaylistContext
import com.example.ui.viewmodel.SearchQuickFilter
import com.example.ui.viewmodel.TokkorUiState

@Composable
fun SearchScreen(
    uiState: TokkorUiState,
    onBackClick: () -> Unit,
    onQueryChange: (String) -> Unit,
    onQuickFilterSelect: (SearchQuickFilter) -> Unit,
    onCategoryFilterSelect: (StoryCategory?) -> Unit,
    onClearFilters: () -> Unit,
    onPlayStory: (Story, PlaylistContext, StoryCategory?) -> Unit,
    onListenStory: (Story) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedLanguage = uiState.userSettings.selectedLanguage

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(VelvetPurple.copy(alpha = 0.58f), RoyalIndigo, ObsidianBlack)
                )
            )
            .statusBarsPadding()
            .testTag("search_screen")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("search_back_btn")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.search_back_cd),
                    tint = ChampagneGold
                )
            }

            Text(
                text = stringResource(R.string.search_screen_title),
                style = MaterialTheme.typography.headlineSmall,
                color = IvoryText
            )
        }

        OutlinedTextField(
            value = uiState.searchQuery,
            onValueChange = onQueryChange,
            placeholder = {
                Text(
                    text = stringResource(R.string.search_input_hint),
                    color = SlateSilver
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = null,
                    tint = TokkorGold
                )
            },
            trailingIcon = {
                if (uiState.searchQuery.isNotEmpty() ||
                    uiState.searchQuickFilter != SearchQuickFilter.ALL ||
                    uiState.searchSelectedCategory != null
                ) {
                    IconButton(
                        onClick = onClearFilters,
                        modifier = Modifier.testTag("search_clear_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = stringResource(R.string.search_clear_cd),
                            tint = SlateSilver
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = DeepNavySurface,
                unfocusedContainerColor = DeepNavySurface,
                focusedBorderColor = TokkorGold,
                unfocusedBorderColor = NavyStroke,
                focusedTextColor = IvoryText,
                unfocusedTextColor = IvoryText,
                cursorColor = ChampagneGold
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .testTag("search_text_field")
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = stringResource(R.string.search_quick_filters_title),
            style = MaterialTheme.typography.labelMedium,
            color = SlateSilver,
            modifier = Modifier.padding(horizontal = 20.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                val selected = uiState.searchQuickFilter == SearchQuickFilter.UNDER_45_SEC
                FilterChip(
                    selected = selected,
                    onClick = { onQuickFilterSelect(SearchQuickFilter.UNDER_45_SEC) },
                    label = { Text(stringResource(R.string.search_filter_under_45)) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = DeepNavySurface,
                        labelColor = SlateSilver,
                        selectedContainerColor = TokkorGold,
                        selectedLabelColor = ObsidianBlack
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selected,
                        borderColor = NavyStroke,
                        selectedBorderColor = ChampagneGold
                    ),
                    modifier = Modifier.testTag("search_chip_under_45")
                )
            }

            item {
                val selected = uiState.searchQuickFilter == SearchQuickFilter.FEATURED_ONLY
                FilterChip(
                    selected = selected,
                    onClick = { onQuickFilterSelect(SearchQuickFilter.FEATURED_ONLY) },
                    label = { Text(stringResource(R.string.search_filter_featured)) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = DeepNavySurface,
                        labelColor = SlateSilver,
                        selectedContainerColor = TokkorGold,
                        selectedLabelColor = ObsidianBlack
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selected,
                        borderColor = NavyStroke,
                        selectedBorderColor = ChampagneGold
                    ),
                    modifier = Modifier.testTag("search_chip_featured")
                )
            }

            items(StoryCategory.entries) { category ->
                val selected = uiState.searchSelectedCategory == category
                FilterChip(
                    selected = selected,
                    onClick = { onCategoryFilterSelect(category) },
                    label = { Text(category.displayName) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = DeepNavySurface,
                        labelColor = SlateSilver,
                        selectedContainerColor = TokkorGold,
                        selectedLabelColor = ObsidianBlack
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = selected,
                        borderColor = NavyStroke,
                        selectedBorderColor = ChampagneGold
                    ),
                    modifier = Modifier.testTag("search_chip_${category.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = stringResource(R.string.search_results_count_format, uiState.searchResults.size),
            style = MaterialTheme.typography.labelMedium,
            color = ChampagneGold,
            modifier = Modifier.padding(horizontal = 20.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (uiState.searchResults.isEmpty()) {
            TokkorEmptyState(
                icon = Icons.Outlined.SearchOff,
                title = stringResource(R.string.search_empty_title),
                body = stringResource(R.string.search_empty_body),
                ctaLabel = stringResource(R.string.search_clear_cd),
                onCtaClick = onClearFilters
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("search_results_list"),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(uiState.searchResults, key = { it.id }) { story ->
                    HorizontalStoryListCard(
                        story = story,
                        selectedLanguage = selectedLanguage,
                        isFavorite = uiState.favoriteIds.contains(story.id),
                        onPlayClick = {
                            onPlayStory(story, PlaylistContext.SEARCH_RESULTS, null)
                        },
                        onListenClick = { onListenStory(story) },
                        onToggleFavorite = { onToggleFavorite(story.id) }
                    )
                }
            }
        }
    }
}
