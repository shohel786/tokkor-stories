package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Man
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material.icons.outlined.Woman
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.PrimaryStoryLanguages
import com.example.data.model.Story
import com.example.data.model.StoryLanguageOption
import com.example.data.model.VoiceGender
import com.example.data.sample.StoryLocalization
import com.example.data.voice.NarrationPlaybackState
import com.example.data.voice.VoiceNarrationState
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.ElevatedNavy
import com.example.ui.theme.EmeraldStream
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavyStroke
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RoyalIndigo
import com.example.ui.theme.SlateSilver
import com.example.ui.theme.TokkorGold
import com.example.ui.theme.TwilightViolet
import com.example.ui.theme.VelvetPurple
import java.util.Locale

@Composable
fun SelectedLanguagePill(
    language: StoryLanguageOption,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(50.dp),
        color = VelvetPurple,
        border = BorderStroke(1.dp, TokkorGold.copy(alpha = 0.65f)),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag("selected_language_pill")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.Language,
                contentDescription = stringResource(R.string.voice_selected_badge_cd),
                tint = ChampagneGold,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = "${language.shortBadge} • ${language.nativeName}",
                style = MaterialTheme.typography.labelMedium,
                color = IvoryText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguageSelectionSheet(
    selectedLanguage: StoryLanguageOption,
    otherSupportedLanguages: List<StoryLanguageOption>,
    onSelectLanguage: (StoryLanguageOption) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = RoyalIndigo,
        contentColor = IvoryText
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
                .testTag("language_selection_sheet")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = VelvetPurple,
                    border = BorderStroke(1.dp, TokkorGold),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Outlined.Language,
                            contentDescription = null,
                            tint = ChampagneGold,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Column {
                    Text(
                        text = stringResource(R.string.voice_language_menu_title),
                        style = MaterialTheme.typography.headlineSmall,
                        color = IvoryText
                    )
                    Text(
                        text = stringResource(R.string.voice_language_menu_subtitle),
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateSilver
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                item {
                    Text(
                        text = stringResource(R.string.voice_primary_languages_header).uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = ChampagneGold
                    )
                }

                items(PrimaryStoryLanguages.all, key = { it.code }) { language ->
                    val isSelected = selectedLanguage.code.equals(language.code, ignoreCase = true)
                    LanguageOptionRow(
                        language = language,
                        isSelected = isSelected,
                        onClick = {
                            onSelectLanguage(language)
                            onDismiss()
                        }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider(color = NavyStroke)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.voice_other_languages_header).uppercase(),
                        style = MaterialTheme.typography.labelMedium,
                        color = ChampagneGold
                    )
                }

                if (otherSupportedLanguages.isEmpty()) {
                    item {
                        Text(
                            text = stringResource(R.string.voice_no_other_languages),
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateSilver,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                } else {
                    items(otherSupportedLanguages, key = { it.bcp47Tag }) { language ->
                        val isSelected = selectedLanguage.code.equals(language.code, ignoreCase = true) ||
                            selectedLanguage.bcp47Tag.equals(language.bcp47Tag, ignoreCase = true)
                        LanguageOptionRow(
                            language = language,
                            isSelected = isSelected,
                            onClick = {
                                onSelectLanguage(language)
                                onDismiss()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LanguageOptionRow(
    language: StoryLanguageOption,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .minimumInteractiveComponentSize()
            .testTag("language_option_${language.code}"),
        shape = RoundedCornerShape(16.dp),
        color = if (isSelected) VelvetPurple else DeepNavySurface,
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) TokkorGold else NavyStroke
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) TokkorGold else MidnightNavy,
                    modifier = Modifier.size(38.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = language.shortBadge,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (isSelected) ObsidianBlack else ChampagneGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = language.nativeName,
                            style = MaterialTheme.typography.titleMedium,
                            color = IvoryText
                        )
                        if (language.isRtl) {
                            Surface(
                                color = TwilightViolet,
                                shape = RoundedCornerShape(50.dp),
                                border = BorderStroke(0.75.dp, TokkorGold.copy(alpha = 0.55f))
                            ) {
                                Text(
                                    text = stringResource(R.string.voice_rtl_badge),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ChampagneGold,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = language.englishName,
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateSilver
                    )
                }
            }

            if (isSelected) {
                Surface(
                    shape = CircleShape,
                    color = TokkorGold,
                    modifier = Modifier.size(26.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = null,
                            tint = ObsidianBlack,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoryVoiceNarrationSheet(
    story: Story,
    voiceState: VoiceNarrationState,
    onOpenLanguageMenu: () -> Unit,
    onSelectVoiceGender: (VoiceGender) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onPlayOrTogglePause: () -> Unit,
    onStop: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val selectedLang = voiceState.selectedLanguage
    val localized = StoryLocalization.getLocalizedContent(story, selectedLang)
    val sentences = StoryLocalization.splitSentences(localized.narrationScript)
    val isThisStoryActive = voiceState.activeStoryId == story.id
    val effectiveState = if (isThisStoryActive) voiceState.playbackState else NarrationPlaybackState.IDLE
    val activeSentenceIndex = if (isThisStoryActive) voiceState.currentSegmentIndex else -1

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = RoyalIndigo,
        contentColor = IvoryText
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
                .testTag("voice_narration_sheet"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header with Language Badge & Switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = VelvetPurple,
                        border = BorderStroke(1.dp, TokkorGold),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Outlined.RecordVoiceOver,
                                contentDescription = null,
                                tint = ChampagneGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Column {
                        Text(
                            text = stringResource(R.string.voice_narrator_sheet_title),
                            style = MaterialTheme.typography.titleLarge,
                            color = IvoryText
                        )
                        val statusLabel = when {
                            !voiceState.isEngineReady && !voiceState.engineUnavailable ->
                                stringResource(R.string.voice_status_initializing)
                            effectiveState == NarrationPlaybackState.PLAYING ->
                                stringResource(R.string.voice_status_speaking)
                            effectiveState == NarrationPlaybackState.PAUSED ->
                                stringResource(R.string.voice_status_paused)
                            effectiveState == NarrationPlaybackState.COMPLETED ->
                                stringResource(R.string.voice_status_completed)
                            else -> stringResource(R.string.voice_status_ready)
                        }
                        Text(
                            text = statusLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (effectiveState == NarrationPlaybackState.PLAYING) EmeraldStream else ChampagneGold
                        )
                    }
                }

                SelectedLanguagePill(
                    language = selectedLang,
                    onClick = onOpenLanguageMenu
                )
            }

            // Graceful fallback notice if device lacks TTS pack
            val notice = voiceState.statusNotice
            if (notice != null) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = TwilightViolet.copy(alpha = 0.65f),
                    border = BorderStroke(1.dp, TokkorGold.copy(alpha = 0.55f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.WarningAmber,
                            contentDescription = null,
                            tint = ChampagneGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = notice,
                            style = MaterialTheme.typography.bodySmall,
                            color = IvoryText
                        )
                    }
                }
            }

            // Story Title & Narration Text Card (RTL-aware for Arabic!)
            val layoutDir = if (selectedLang.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
            CompositionLocalProvider(LocalLayoutDirection provides layoutDir) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = DeepNavySurface,
                    border = BorderStroke(1.dp, NavyStroke),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(VelvetPurple.copy(alpha = 0.45f), DeepNavySurface)
                                )
                            )
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = localized.localizedTitle,
                            style = MaterialTheme.typography.headlineSmall,
                            color = ChampagneGold
                        )
                        sentences.forEachIndexed { idx, sentence ->
                            val highlighted = isThisStoryActive &&
                                idx == activeSentenceIndex &&
                                (effectiveState == NarrationPlaybackState.PLAYING ||
                                    effectiveState == NarrationPlaybackState.PAUSED)
                            Text(
                                text = sentence,
                                style = MaterialTheme.typography.bodyLarge,
                                color = if (highlighted) ChampagneGold else IvoryText.copy(alpha = 0.88f),
                                fontWeight = if (highlighted) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            // Play / Pause / Resume & Stop Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val primaryLabel = when (effectiveState) {
                    NarrationPlaybackState.PLAYING -> stringResource(R.string.voice_pause)
                    NarrationPlaybackState.PAUSED -> stringResource(R.string.voice_resume)
                    NarrationPlaybackState.COMPLETED -> stringResource(R.string.voice_replay)
                    else -> stringResource(R.string.voice_play)
                }
                val primaryIcon = if (effectiveState == NarrationPlaybackState.PLAYING) {
                    Icons.Filled.Pause
                } else {
                    Icons.Filled.PlayArrow
                }

                Button(
                    onClick = onPlayOrTogglePause,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TokkorGold,
                        contentColor = ObsidianBlack
                    ),
                    shape = RoundedCornerShape(50.dp),
                    modifier = Modifier
                        .weight(1f)
                        .minimumInteractiveComponentSize()
                        .testTag("voice_play_pause_btn")
                ) {
                    Icon(
                        imageVector = primaryIcon,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = primaryLabel,
                        style = MaterialTheme.typography.labelLarge
                    )
                }

                if (effectiveState == NarrationPlaybackState.PLAYING ||
                    effectiveState == NarrationPlaybackState.PAUSED
                ) {
                    OutlinedButton(
                        onClick = onStop,
                        border = BorderStroke(1.dp, NavyStroke),
                        shape = RoundedCornerShape(50.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("voice_stop_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Stop,
                            contentDescription = null,
                            tint = SlateSilver,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = stringResource(R.string.voice_stop),
                            color = IvoryText
                        )
                    }
                }
            }

            // Male / Female Voice Selector
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = stringResource(R.string.voice_gender_label),
                    style = MaterialTheme.typography.labelMedium,
                    color = ChampagneGold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    VoiceGender.entries.forEach { gender ->
                        val selected = voiceState.voiceGender == gender
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectVoiceGender(gender) },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (gender == VoiceGender.FEMALE) {
                                        Icons.Outlined.Woman
                                    } else {
                                        Icons.Outlined.Man
                                    },
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = stringResource(
                                        if (gender == VoiceGender.FEMALE) {
                                            R.string.voice_gender_female
                                        } else {
                                            R.string.voice_gender_male
                                        }
                                    )
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = DeepNavySurface,
                                labelColor = SlateSilver,
                                iconColor = ChampagneGold,
                                selectedContainerColor = TokkorGold,
                                selectedLabelColor = ObsidianBlack,
                                selectedLeadingIconColor = ObsidianBlack
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                borderColor = NavyStroke,
                                selectedBorderColor = ChampagneGold
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("voice_gender_${gender.name.lowercase()}")
                        )
                    }
                }
            }

            // Voice Speed Control
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Speed,
                            contentDescription = null,
                            tint = ChampagneGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = stringResource(R.string.voice_speed_label),
                            style = MaterialTheme.typography.labelMedium,
                            color = ChampagneGold
                        )
                    }
                    Text(
                        text = String.format(Locale.US, "%.2fx", voiceState.speechSpeed),
                        style = MaterialTheme.typography.labelLarge,
                        color = IvoryText
                    )
                }

                Slider(
                    value = voiceState.speechSpeed,
                    onValueChange = onSpeedChange,
                    valueRange = 0.65f..1.65f,
                    colors = SliderDefaults.colors(
                        thumbColor = ChampagneGold,
                        activeTrackColor = TokkorGold,
                        inactiveTrackColor = NavyStroke
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("voice_speed_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { preset ->
                        val isClose = kotlin.math.abs(voiceState.speechSpeed - preset) < 0.04f
                        TextButton(
                            onClick = { onSpeedChange(preset) },
                            modifier = Modifier.testTag("voice_speed_preset_${preset}")
                        ) {
                            Text(
                                text = "${preset}x",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isClose) ChampagneGold else SlateSilver,
                                fontWeight = if (isClose) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }
    }
}
