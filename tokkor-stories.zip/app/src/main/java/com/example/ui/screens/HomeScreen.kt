package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Story
import com.example.data.model.StoryCategory
import com.example.ui.components.FeaturedStoryHeroCard
import com.example.ui.components.SelectedLanguagePill
import com.example.ui.components.VerticalStoryReelCard
import com.example.ui.components.categoryIcon
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.ElevatedNavy
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavyStroke
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RoyalIndigo
import com.example.ui.theme.SlateSilver
import com.example.ui.theme.TokkorGold
import com.example.ui.theme.VelvetPurple
import com.example.ui.viewmodel.PlaylistContext
import com.example.ui.viewmodel.TokkorUiState

@Composable
fun HomeScreen(
    uiState: TokkorUiState,
    onSearchClick: () -> Unit,
    onLanguageMenuClick: () -> Unit,
    onSeeAllCategoriesClick: () -> Unit,
    onSelectHomeCategory: (StoryCategory?) -> Unit,
    onPlayStory: (Story, PlaylistContext, StoryCategory?) -> Unit,
    onListenStory: (Story) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val featuredStories = uiState.featuredStories
    val pagerState = rememberPagerState(pageCount = { featuredStories.size.coerceAtLeast(1) })
    val selectedLanguage = uiState.userSettings.selectedLanguage

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        VelvetPurple.copy(alpha = 0.65f),
                        RoyalIndigo,
                        ObsidianBlack
                    )
                )
            )
    ) {
        val columnCount = when {
            maxWidth >= 840.dp -> 4
            maxWidth >= 600.dp -> 3
            else -> 2
        }
        val chunkedShorts = uiState.homeShorts.chunked(columnCount)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("home_screen_list"),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Top International Editorial Header with Language Selector Badge
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 14.dp, top = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            modifier = Modifier.size(46.dp),
                            shape = CircleShape,
                            border = BorderStroke(1.5.dp, ChampagneGold),
                            color = RoyalIndigo
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_tokkor_logo),
                                contentDescription = stringResource(R.string.app_name),
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Column {
                            Text(
                                text = stringResource(R.string.home_greeting_eyebrow),
                                style = MaterialTheme.typography.labelSmall,
                                color = TokkorGold
                            )
                            Text(
                                text = stringResource(R.string.home_header_title),
                                style = MaterialTheme.typography.headlineMedium,
                                color = IvoryText
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SelectedLanguagePill(
                            language = selectedLanguage,
                            onClick = onLanguageMenuClick
                        )

                        IconButton(
                            onClick = onSearchClick,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("home_header_search_btn")
                        ) {
                            Surface(
                                modifier = Modifier.size(40.dp),
                                shape = CircleShape,
                                color = ElevatedNavy,
                                border = BorderStroke(1.dp, NavyStroke)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Filled.Search,
                                        contentDescription = stringResource(R.string.search_screen_title),
                                        tint = ChampagneGold,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Inline Search Pill
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(onClick = onSearchClick)
                        .minimumInteractiveComponentSize()
                        .testTag("home_search_bar_pill"),
                    shape = RoundedCornerShape(16.dp),
                    color = DeepNavySurface,
                    border = BorderStroke(1.dp, NavyStroke)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = null,
                            tint = TokkorGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = stringResource(R.string.home_search_placeholder),
                            style = MaterialTheme.typography.bodyMedium,
                            color = SlateSilver
                        )
                    }
                }
            }

            // Featured Short Stories Section
            if (featuredStories.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.AutoAwesome,
                                    contentDescription = null,
                                    tint = ChampagneGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = stringResource(R.string.home_featured_section_title),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = IvoryText
                                )
                            }
                            Text(
                                text = "${pagerState.currentPage + 1} / ${featuredStories.size}",
                                style = MaterialTheme.typography.labelMedium,
                                color = ChampagneGold
                            )
                        }

                        HorizontalPager(
                            state = pagerState,
                            contentPadding = PaddingValues(horizontal = 20.dp),
                            pageSpacing = 14.dp
                        ) { page ->
                            val story = featuredStories[page]
                            FeaturedStoryHeroCard(
                                story = story,
                                selectedLanguage = selectedLanguage,
                                isFavorite = uiState.favoriteIds.contains(story.id),
                                onPlayClick = {
                                    onPlayStory(story, PlaylistContext.FEATURED, null)
                                },
                                onListenClick = { onListenStory(story) },
                                onToggleFavorite = { onToggleFavorite(story.id) }
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            repeat(featuredStories.size) { index ->
                                val selected = pagerState.currentPage == index
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 4.dp)
                                        .height(6.dp)
                                        .width(if (selected) 22.dp else 6.dp)
                                        .clip(CircleShape)
                                        .background(if (selected) TokkorGold else NavyStroke)
                                )
                            }
                        }
                    }
                }
            }

            // Categories Quick Strip
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 20.dp, end = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.home_categories_strip_title),
                            style = MaterialTheme.typography.titleLarge,
                            color = IvoryText
                        )
                        TextButton(
                            onClick = onSeeAllCategoriesClick,
                            modifier = Modifier.testTag("home_see_all_categories_btn")
                        ) {
                            Text(
                                text = stringResource(R.string.home_see_all),
                                style = MaterialTheme.typography.labelLarge,
                                color = ChampagneGold
                            )
                        }
                    }

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            val isAllSelected = uiState.selectedHomeCategory == null
                            FilterChip(
                                selected = isAllSelected,
                                onClick = { onSelectHomeCategory(null) },
                                label = { Text(stringResource(R.string.home_all_filter)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = DeepNavySurface,
                                    labelColor = SlateSilver,
                                    selectedContainerColor = TokkorGold,
                                    selectedLabelColor = ObsidianBlack
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isAllSelected,
                                    borderColor = NavyStroke,
                                    selectedBorderColor = ChampagneGold
                                ),
                                modifier = Modifier.testTag("home_cat_chip_all")
                            )
                        }

                        items(StoryCategory.entries) { category ->
                            val isSelected = uiState.selectedHomeCategory == category
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectHomeCategory(category) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = categoryIcon(category),
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = { Text(category.displayName) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = DeepNavySurface,
                                    labelColor = SlateSilver,
                                    iconColor = ChampagneGold,
                                    selectedContainerColor = TokkorGold,
                                    selectedLabelColor = ObsidianBlack,
                                    selectedLeadingIconColor = ObsidianBlack
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = NavyStroke,
                                    selectedBorderColor = ChampagneGold
                                ),
                                modifier = Modifier.testTag("home_cat_chip_${category.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // Short Video Stories Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.home_shorts_section_title),
                            style = MaterialTheme.typography.titleLarge,
                            color = IvoryText
                        )
                        Text(
                            text = stringResource(R.string.home_shorts_section_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateSilver
                        )
                    }
                    Text(
                        text = "${uiState.homeShorts.size} reels",
                        style = MaterialTheme.typography.labelMedium,
                        color = TokkorGold
                    )
                }
            }

            // Responsive Multi-Column Short Stories Grid
            items(chunkedShorts) { rowStories ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowStories.forEach { story ->
                        VerticalStoryReelCard(
                            story = story,
                            selectedLanguage = selectedLanguage,
                            isFavorite = uiState.favoriteIds.contains(story.id),
                            onPlayClick = {
                                val context = if (uiState.selectedHomeCategory != null) {
                                    PlaylistContext.CATEGORY
                                } else {
                                    PlaylistContext.ALL_STORIES
                                }
                                onPlayStory(story, context, uiState.selectedHomeCategory)
                            },
                            onToggleFavorite = { onToggleFavorite(story.id) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    repeat(columnCount - rowStories.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}
