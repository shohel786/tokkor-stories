package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val TokkorDarkColorScheme = darkColorScheme(
    primary = TokkorGold,
    onPrimary = ObsidianBlack,
    primaryContainer = VelvetPurple,
    onPrimaryContainer = ChampagneGold,
    secondary = ChampagneGold,
    onSecondary = ObsidianBlack,
    secondaryContainer = ElevatedNavy,
    onSecondaryContainer = IvoryText,
    tertiary = TwilightViolet,
    onTertiary = IvoryText,
    background = ObsidianBlack,
    onBackground = IvoryText,
    surface = DeepObsidian,
    onSurface = IvoryText,
    surfaceVariant = DeepNavySurface,
    onSurfaceVariant = SlateSilver,
    surfaceContainerLowest = ObsidianBlack,
    surfaceContainerLow = RoyalIndigo,
    surfaceContainer = MidnightNavy,
    surfaceContainerHigh = VelvetPurple,
    surfaceContainerHighest = ElevatedNavy,
    outline = NavyStroke,
    outlineVariant = BurnishedGold,
    error = CrimsonRose,
    onError = IvoryText
)

val TokkorShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun TokkorStoriesTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TokkorDarkColorScheme,
        typography = TokkorTypography,
        shapes = TokkorShapes,
        content = content
    )
}
