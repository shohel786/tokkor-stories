package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Story
import com.example.data.model.StoryCategory
import com.example.ui.components.HorizontalStoryListCard
import com.example.ui.components.categoryIcon
import com.example.ui.theme.BurnishedGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.ElevatedNavy
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavyStroke
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RoyalIndigo
import com.example.ui.theme.SlateSilver
import com.example.ui.theme.TokkorGold
import com.example.ui.theme.VelvetPurple
import com.example.ui.viewmodel.PlaylistContext
import com.example.ui.viewmodel.TokkorUiState

@Composable
fun CategoriesScreen(
    uiState: TokkorUiState,
    onSelectCategory: (StoryCategory?) -> Unit,
    onSearchClick: () -> Unit,
    onPlayStory: (Story, PlaylistContext, StoryCategory?) -> Unit,
    onListenStory: (Story) -> Unit,
    onToggleFavorite: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedCategory = uiState.selectedCategoryScreenFilter
    val selectedLanguage = uiState.userSettings.selectedLanguage

    if (selectedCategory != null) {
        BackHandler {
            onSelectCategory(null)
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(VelvetPurple.copy(alpha = 0.55f), RoyalIndigo, ObsidianBlack)
                )
            )
    ) {
        val columnCount = if (maxWidth >= 600.dp) 3 else 2

        if (selectedCategory == null) {
            val categories = StoryCategory.entries
            val rows = categories.chunked(columnCount)

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("categories_grid_screen"),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.categories_screen_title),
                                style = MaterialTheme.typography.displaySmall,
                                color = IvoryText
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stringResource(R.string.categories_screen_subtitle),
                                style = MaterialTheme.typography.bodyMedium,
                                color = SlateSilver
                            )
                        }

                        IconButton(
                            onClick = onSearchClick,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("categories_search_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = stringResource(R.string.search_screen_title),
                                tint = ChampagneGold
                            )
                        }
                    }
                }

                items(rows) { rowCats ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowCats.forEach { category ->
                            val count = uiState.allStories.count { it.category == category }
                            CategoryTileCard(
                                category = category,
                                storyCount = count,
                                onClick = { onSelectCategory(category) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        repeat(columnCount - rowCats.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        } else {
            val categoryStories = uiState.allStories.filter { it.category == selectedCategory }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("category_detail_list"),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Surface(
                                onClick = { onSelectCategory(null) },
                                shape = RoundedCornerShape(50.dp),
                                color = ElevatedNavy,
                                border = BorderStroke(1.dp, NavyStroke),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("category_back_btn")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = null,
                                        tint = ChampagneGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = stringResource(R.string.categories_back_to_all),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = IvoryText
                                    )
                                }
                            }

                            if (categoryStories.isNotEmpty()) {
                                Button(
                                    onClick = {
                                        onPlayStory(
                                            categoryStories.first(),
                                            PlaylistContext.CATEGORY,
                                            selectedCategory
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = TokkorGold,
                                        contentColor = ObsidianBlack
                                    ),
                                    shape = RoundedCornerShape(50.dp),
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("category_play_all_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = stringResource(R.string.categories_play_all),
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                }
                            }
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = selectedCategory.displayName,
                                style = MaterialTheme.typography.displaySmall,
                                color = ChampagneGold
                            )
                            Text(
                                text = selectedCategory.tagline,
                                style = MaterialTheme.typography.bodyMedium,
                                color = SlateSilver
                            )
                        }
                    }
                }

                items(categoryStories, key = { it.id }) { story ->
                    HorizontalStoryListCard(
                        story = story,
                        selectedLanguage = selectedLanguage,
                        isFavorite = uiState.favoriteIds.contains(story.id),
                        onPlayClick = {
                            onPlayStory(story, PlaylistContext.CATEGORY, selectedCategory)
                        },
                        onListenClick = { onListenStory(story) },
                        onToggleFavorite = { onToggleFavorite(story.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryTileCard(
    category: StoryCategory,
    storyCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .height(172.dp)
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .testTag("category_tile_${category.name.lowercase()}"),
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(
            width = 1.dp,
            brush = Brush.verticalGradient(
                listOf(BurnishedGold.copy(alpha = 0.65f), NavyStroke)
            )
        ),
        colors = CardDefaults.cardColors(containerColor = DeepNavySurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(VelvetPurple, MidnightNavy, ObsidianBlack.copy(alpha = 0.85f))
                    )
                )
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        modifier = Modifier.size(44.dp),
                        shape = CircleShape,
                        color = TokkorGold.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, TokkorGold.copy(alpha = 0.55f))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = categoryIcon(category),
                                contentDescription = category.displayName,
                                tint = ChampagneGold,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Surface(
                        color = ObsidianBlack.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(50.dp),
                        border = BorderStroke(0.75.dp, NavyStroke)
                    ) {
                        Text(
                            text = stringResource(R.string.categories_story_count_format, storyCount),
                            style = MaterialTheme.typography.labelSmall,
                            color = ChampagneGold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = category.displayName,
                        style = MaterialTheme.typography.titleLarge,
                        color = IvoryText
                    )
                    Text(
                        text = category.tagline,
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateSilver,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
