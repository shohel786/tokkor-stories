package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.compose.ContentFrame
import androidx.media3.ui.compose.SURFACE_TYPE_TEXTURE_VIEW
import com.example.R
import com.example.data.model.Story
import com.example.data.model.UserSettings
import com.example.data.sample.StoryLocalization
import com.example.data.voice.NarrationPlaybackState
import com.example.data.voice.VoiceNarrationState
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.EmeraldStream
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MidnightNavy
import com.example.ui.theme.NavyStroke
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateSilver
import com.example.ui.theme.TokkorGold
import com.example.ui.theme.VelvetPurple
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun VerticalPlayerScreen(
    stories: List<Story>,
    initialStoryId: String,
    favoriteIds: Set<String>,
    userSettings: UserSettings,
    voiceState: VoiceNarrationState,
    onOpenLanguageMenu: () -> Unit,
    onOpenVoiceSheet: (Story) -> Unit,
    onPrepareVoiceForStory: (Story) -> Unit,
    onStopVoiceOnClose: () -> Unit,
    onToggleFavorite: (String) -> Unit,
    onCloseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (stories.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(ObsidianBlack),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stringResource(R.string.search_empty_title),
                color = IvoryText
            )
        }
        return
    }

    val initialPage = remember(stories, initialStoryId) {
        stories.indexOfFirst { it.id == initialStoryId }.coerceAtLeast(0)
    }
    val pagerState = rememberPagerState(
        initialPage = initialPage,
        pageCount = { stories.size }
    )
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    var isMuted by remember(userSettings.startMuted) { mutableStateOf(userSettings.startMuted) }
    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(true) }
    var hasStreamError by remember { mutableStateOf(false) }
    var currentPosMs by remember { mutableLongStateOf(0L) }
    var totalDurationMs by remember { mutableLongStateOf(45_000L) }
    var showCenterTapHint by remember { mutableStateOf(false) }
    var synopsisExpanded by remember { mutableStateOf(false) }

    val exoPlayer = remember(context) {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = true
        }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        isBuffering = true
                        hasStreamError = false
                    }
                    Player.STATE_READY -> {
                        isBuffering = false
                        hasStreamError = false
                        val d = exoPlayer.duration
                        if (d > 0L) {
                            totalDurationMs = d
                        }
                    }
                    Player.STATE_ENDED -> {
                        isBuffering = false
                        if (userSettings.autoPlayNext && pagerState.currentPage < stories.lastIndex) {
                            coroutineScope.launch {
                                pagerState.animateScrollToPage(pagerState.currentPage + 1)
                            }
                        } else if (userSettings.loopStory) {
                            exoPlayer.seekTo(0L)
                            exoPlayer.playWhenReady = true
                        }
                    }
                    Player.STATE_IDLE -> Unit
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                hasStreamError = true
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            onStopVoiceOnClose()
        }
    }

    LifecycleEventEffect(Lifecycle.Event.ON_PAUSE) {
        exoPlayer.pause()
    }

    // Duck video audio gracefully while TTS narration is actively speaking
    val isVoiceSpeaking = voiceState.playbackState == NarrationPlaybackState.PLAYING
    LaunchedEffect(isMuted, isVoiceSpeaking) {
        exoPlayer.volume = when {
            isMuted -> 0f
            isVoiceSpeaking -> 0.08f
            else -> 1f
        }
    }

    fun loadStoryAtPage(pageIndex: Int) {
        val activeStory = stories[pageIndex]
        onPrepareVoiceForStory(activeStory)
        hasStreamError = false
        isBuffering = true
        currentPosMs = 0L
        totalDurationMs = activeStory.durationSeconds * 1000L

        val mediaItem = MediaItem.Builder()
            .setMediaId(activeStory.id)
            .setUri(activeStory.videoUrl)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(activeStory.clipStartMs)
                    .setEndPositionMs(activeStory.clipEndMs)
                    .build()
            )
            .build()

        exoPlayer.repeatMode = if (!userSettings.autoPlayNext && userSettings.loopStory) {
            Player.REPEAT_MODE_ONE
        } else {
            Player.REPEAT_MODE_OFF
        }
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = true
    }

    LaunchedEffect(pagerState.settledPage) {
        loadStoryAtPage(pagerState.settledPage)
    }

    LaunchedEffect(exoPlayer, pagerState.settledPage) {
        while (true) {
            if (exoPlayer.isPlaying) {
                currentPosMs = exoPlayer.currentPosition.coerceAtLeast(0L)
                val dur = exoPlayer.duration
                if (dur > 0L) totalDurationMs = dur
            }
            delay(250L)
        }
    }

    LaunchedEffect(showCenterTapHint) {
        if (showCenterTapHint) {
            delay(650L)
            showCenterTapHint = false
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack)
            .testTag("vertical_player_screen")
    ) {
        VerticalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val story = stories[page]
            val isCurrentPage = page == pagerState.settledPage

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        if (isCurrentPage) {
                            if (exoPlayer.isPlaying) {
                                exoPlayer.pause()
                            } else {
                                exoPlayer.play()
                            }
                            showCenterTapHint = true
                        }
                    }
            ) {
                if (isCurrentPage) {
                    ContentFrame(
                        player = exoPlayer,
                        surfaceType = SURFACE_TYPE_TEXTURE_VIEW,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                        shutter = {
                            StoryCoverBackdrop(story = story)
                        }
                    )
                } else {
                    StoryCoverBackdrop(story = story)
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    ObsidianBlack.copy(alpha = 0.72f),
                                    VelvetPurple.copy(alpha = 0.14f),
                                    MidnightNavy.copy(alpha = 0.20f),
                                    ObsidianBlack.copy(alpha = 0.94f)
                                )
                            )
                        )
                )

                if (isCurrentPage) {
                    if (hasStreamError) {
                        Column(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(horizontal = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.player_stream_error),
                                style = MaterialTheme.typography.bodyMedium,
                                color = IvoryText
                            )
                            Button(
                                onClick = { loadStoryAtPage(page) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = TokkorGold,
                                    contentColor = ObsidianBlack
                                ),
                                shape = RoundedCornerShape(50.dp),
                                modifier = Modifier.testTag("player_retry_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(R.string.player_retry))
                            }
                        }
                    } else if (isBuffering) {
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(
                                color = TokkorGold,
                                trackColor = DeepNavySurface,
                                modifier = Modifier.size(44.dp)
                            )
                            Text(
                                text = stringResource(R.string.player_buffering),
                                style = MaterialTheme.typography.labelMedium,
                                color = ChampagneGold
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = showCenterTapHint || !isPlaying,
                        enter = fadeIn(),
                        exit = fadeOut(),
                        modifier = Modifier.align(Alignment.Center)
                    ) {
                        if (!isBuffering && !hasStreamError) {
                            Surface(
                                shape = CircleShape,
                                color = ObsidianBlack.copy(alpha = 0.65f),
                                border = BorderStroke(1.5.dp, TokkorGold),
                                modifier = Modifier.size(72.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                        contentDescription = null,
                                        tint = ChampagneGold,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        val activeStory = stories[pagerState.currentPage]
        val isFavorite = favoriteIds.contains(activeStory.id)
        val selectedLanguage = userSettings.selectedLanguage
        val localized = StoryLocalization.getLocalizedContent(activeStory, selectedLanguage)
        val contentDir = if (selectedLanguage.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

        // Top HUD Overlay with Selected Language Pill + Voice Narrator + Mute
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onCloseClick,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("player_close_btn")
            ) {
                Surface(
                    shape = CircleShape,
                    color = ObsidianBlack.copy(alpha = 0.68f),
                    border = BorderStroke(1.dp, NavyStroke),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.player_close_cd),
                            tint = IvoryText,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Selected Language + Story Counter Pill
            Surface(
                onClick = onOpenLanguageMenu,
                color = VelvetPurple.copy(alpha = 0.85f),
                shape = RoundedCornerShape(50.dp),
                border = BorderStroke(1.dp, TokkorGold.copy(alpha = 0.65f)),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("player_language_pill")
            ) {
                Text(
                    text = "${selectedLanguage.shortBadge} ${selectedLanguage.nativeName} • ${pagerState.currentPage + 1}/${stories.size}",
                    style = MaterialTheme.typography.labelMedium,
                    color = ChampagneGold,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Voice Narrator Sheet Trigger
                IconButton(
                    onClick = { onOpenVoiceSheet(activeStory) },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_voice_narrator_btn")
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (isVoiceSpeaking) TokkorGold else VelvetPurple.copy(alpha = 0.82f),
                        border = BorderStroke(
                            1.dp,
                            if (isVoiceSpeaking) EmeraldStream else TokkorGold.copy(alpha = 0.7f)
                        ),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Outlined.RecordVoiceOver,
                                contentDescription = stringResource(R.string.voice_narrator_btn),
                                tint = if (isVoiceSpeaking) ObsidianBlack else ChampagneGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                IconButton(
                    onClick = { isMuted = !isMuted },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_mute_btn")
                ) {
                    Surface(
                        shape = CircleShape,
                        color = ObsidianBlack.copy(alpha = 0.68f),
                        border = BorderStroke(1.dp, NavyStroke),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isMuted) {
                                    Icons.AutoMirrored.Filled.VolumeOff
                                } else {
                                    Icons.AutoMirrored.Filled.VolumeUp
                                },
                                contentDescription = stringResource(
                                    if (isMuted) R.string.player_unmute_cd else R.string.player_mute_cd
                                ),
                                tint = if (isMuted) SlateSilver else ChampagneGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        // Bottom Localized Story Details + Seek Bar + Next / Previous / Play / Favorite Controls
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides contentDir) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { synopsisExpanded = !synopsisExpanded },
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "${activeStory.category.displayName.uppercase()} • ${activeStory.author.uppercase()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TokkorGold
                        )
                        Text(
                            text = localized.localizedTitle,
                            style = MaterialTheme.typography.headlineMedium,
                            color = IvoryText,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = localized.narrationScript,
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateSilver,
                            maxLines = if (synopsisExpanded) 6 else 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        onClick = { onOpenVoiceSheet(activeStory) },
                        shape = RoundedCornerShape(50.dp),
                        color = VelvetPurple.copy(alpha = 0.88f),
                        border = BorderStroke(1.dp, TokkorGold.copy(alpha = 0.7f)),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("player_voice_pill_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.RecordVoiceOver,
                                contentDescription = null,
                                tint = ChampagneGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = stringResource(R.string.voice_narrator_btn),
                                style = MaterialTheme.typography.labelMedium,
                                color = IvoryText
                            )
                        }
                    }

                    IconButton(
                        onClick = { onToggleFavorite(activeStory.id) },
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("player_favorite_btn")
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = DeepNavySurface.copy(alpha = 0.85f),
                            border = BorderStroke(
                                width = 1.2.dp,
                                color = if (isFavorite) CrimsonRose else TokkorGold.copy(alpha = 0.6f)
                            ),
                            modifier = Modifier.size(46.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (isFavorite) {
                                        Icons.Filled.Favorite
                                    } else {
                                        Icons.Outlined.FavoriteBorder
                                    },
                                    contentDescription = stringResource(
                                        if (isFavorite) {
                                            R.string.favorites_toggle_remove_cd
                                        } else {
                                            R.string.favorites_toggle_add_cd
                                        }
                                    ),
                                    tint = if (isFavorite) CrimsonRose else IvoryText,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }

            val safeDuration = totalDurationMs.coerceAtLeast(1_000L)
            val progressFraction = (currentPosMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Slider(
                    value = progressFraction,
                    onValueChange = { fraction ->
                        val targetMs = (fraction * safeDuration).toLong()
                        currentPosMs = targetMs
                        exoPlayer.seekTo(targetMs)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = ChampagneGold,
                        activeTrackColor = TokkorGold,
                        inactiveTrackColor = NavyStroke
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                        .testTag("player_seek_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = formatMs(currentPosMs),
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateSilver
                    )
                    Text(
                        text = stringResource(R.string.player_swipe_hint),
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateSilver.copy(alpha = 0.75f)
                    )
                    Text(
                        text = formatMs(safeDuration),
                        style = MaterialTheme.typography.labelSmall,
                        color = ChampagneGold
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val hasPrev = pagerState.currentPage > 0
                val hasNext = pagerState.currentPage < stories.lastIndex

                Surface(
                    onClick = {
                        if (hasPrev) {
                            coroutineScope.launch {
                                pagerState.animateScrollToPage(pagerState.currentPage - 1)
                            }
                        }
                    },
                    enabled = hasPrev,
                    shape = RoundedCornerShape(50.dp),
                    color = if (hasPrev) DeepNavySurface.copy(alpha = 0.9f) else DeepNavySurface.copy(alpha = 0.35f),
                    border = BorderStroke(
                        1.dp,
                        if (hasPrev) NavyStroke else NavyStroke.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("player_previous_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SkipPrevious,
                            contentDescription = null,
                            tint = if (hasPrev) ChampagneGold else SlateSilver.copy(alpha = 0.4f),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = stringResource(R.string.player_previous_story),
                            style = MaterialTheme.typography.labelLarge,
                            color = if (hasPrev) IvoryText else SlateSilver.copy(alpha = 0.4f)
                        )
                    }
                }

                Surface(
                    onClick = {
                        if (exoPlayer.isPlaying) {
                            exoPlayer.pause()
                        } else {
                            exoPlayer.play()
                        }
                    },
                    shape = CircleShape,
                    color = TokkorGold,
                    modifier = Modifier
                        .size(54.dp)
                        .testTag("player_play_pause_btn")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = stringResource(
                                if (isPlaying) R.string.player_pause_cd else R.string.player_play_cd
                            ),
                            tint = ObsidianBlack,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Surface(
                    onClick = {
                        if (hasNext) {
                            coroutineScope.launch {
                                pagerState.animateScrollToPage(pagerState.currentPage + 1)
                            }
                        }
                    },
                    enabled = hasNext,
                    shape = RoundedCornerShape(50.dp),
                    color = if (hasNext) DeepNavySurface.copy(alpha = 0.9f) else DeepNavySurface.copy(alpha = 0.35f),
                    border = BorderStroke(
                        1.dp,
                        if (hasNext) TokkorGold.copy(alpha = 0.55f) else NavyStroke.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("player_next_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.player_next_story),
                            style = MaterialTheme.typography.labelLarge,
                            color = if (hasNext) IvoryText else SlateSilver.copy(alpha = 0.4f)
                        )
                        Icon(
                            imageVector = Icons.Filled.SkipNext,
                            contentDescription = null,
                            tint = if (hasNext) ChampagneGold else SlateSilver.copy(alpha = 0.4f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StoryCoverBackdrop(story: Story) {
    Image(
        painter = painterResource(id = story.coverResId),
        contentDescription = story.title,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize()
    )
}

private fun formatMs(ms: Long): String {
    val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
    val mins = totalSeconds / 60L
    val secs = totalSeconds % 60L
    return "$mins:${secs.toString().padStart(2, '0')}"
}
