package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
data object SplashRoute

@Serializable
data object HomeRoute

@Serializable
data object CategoriesRoute

@Serializable
data object FavoritesRoute

@Serializable
data object SettingsRoute

@Serializable
data object SearchRoute

@Serializable
data class PlayerRoute(
    val storyId: String,
    val playlistContext: String = "ALL_STORIES",
    val categoryName: String? = null
)
