package com.example.data.repository

import com.example.data.integrations.AdMonetizationAdapter
import com.example.data.integrations.LocalSampleCatalogProvider
import com.example.data.integrations.NoOpAdMonetizationAdapter
import com.example.data.integrations.RemoteStoryCatalogProvider
import com.example.data.local.FavoriteStoryDao
import com.example.data.local.FavoriteStoryEntity
import com.example.data.local.SettingsDataStore
import com.example.data.model.Story
import com.example.data.model.StoryCategory
import com.example.data.model.StoryLanguageOption
import com.example.data.model.UserSettings
import com.example.data.model.VideoQuality
import com.example.data.model.VoiceGender
import com.example.data.sample.SampleStoriesCatalog
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class StoryRepository(
    private val favoriteStoryDao: FavoriteStoryDao,
    private val settingsDataStore: SettingsDataStore,
    private val catalogProvider: RemoteStoryCatalogProvider =
        LocalSampleCatalogProvider(SampleStoriesCatalog.stories),
    val adMonetizationAdapter: AdMonetizationAdapter = NoOpAdMonetizationAdapter()
) {
    private val _stories = MutableStateFlow(SampleStoriesCatalog.stories)
    val stories: Flow<List<Story>> = _stories.asStateFlow()

    val favoriteIds: Flow<List<String>> = favoriteStoryDao.observeFavoriteIds()

    val userSettings: Flow<UserSettings> = settingsDataStore.userSettings

    val integrationStatus: Pair<String, String>
        get() = catalogProvider.providerName to adMonetizationAdapter.engineName

    suspend fun refreshCatalog() {
        _stories.value = catalogProvider.fetchLatestStories()
    }

    suspend fun toggleFavorite(storyId: String, currentlyFavorite: Boolean) {
        if (currentlyFavorite) {
            favoriteStoryDao.removeFavorite(storyId)
        } else {
            favoriteStoryDao.addFavorite(FavoriteStoryEntity(storyId = storyId))
        }
    }

    suspend fun clearAllFavorites() {
        favoriteStoryDao.clearAllFavorites()
    }

    suspend fun setAutoPlayNext(enabled: Boolean) = settingsDataStore.setAutoPlayNext(enabled)
    suspend fun setStartMuted(muted: Boolean) = settingsDataStore.setStartMuted(muted)
    suspend fun setLoopStory(loop: Boolean) = settingsDataStore.setLoopStory(loop)
    suspend fun setVideoQuality(quality: VideoQuality) = settingsDataStore.setVideoQuality(quality)
    suspend fun setLanguage(language: StoryLanguageOption) = settingsDataStore.setLanguage(language)
    suspend fun setVoiceGender(gender: VoiceGender) = settingsDataStore.setVoiceGender(gender)
    suspend fun setVoiceSpeed(speed: Float) = settingsDataStore.setVoiceSpeed(speed)

    fun storiesForCategory(category: StoryCategory): List<Story> =
        _stories.value.filter { it.category == category }
}
