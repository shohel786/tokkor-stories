package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.PrimaryStoryLanguages
import com.example.data.model.StoryLanguageOption
import com.example.data.model.UserSettings
import com.example.data.model.VideoQuality
import com.example.data.model.VoiceGender
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.tokkorDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "tokkor_user_settings"
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val AUTO_PLAY_NEXT = booleanPreferencesKey("auto_play_next")
        val START_MUTED = booleanPreferencesKey("start_muted")
        val LOOP_STORY = booleanPreferencesKey("loop_story")
        val VIDEO_QUALITY = stringPreferencesKey("video_quality")
        val LANGUAGE_CODE = stringPreferencesKey("language_code")
        val LANGUAGE_NAME = stringPreferencesKey("language_name")
        val VOICE_GENDER = stringPreferencesKey("voice_gender")
        val VOICE_SPEED = floatPreferencesKey("voice_speed")
    }

    val userSettings: Flow<UserSettings> = context.tokkorDataStore.data.map { prefs ->
        val qualityName = prefs[Keys.VIDEO_QUALITY] ?: VideoQuality.AUTO.name
        val quality = runCatching { VideoQuality.valueOf(qualityName) }
            .getOrDefault(VideoQuality.AUTO)

        val genderName = prefs[Keys.VOICE_GENDER] ?: VoiceGender.FEMALE.name
        val gender = runCatching { VoiceGender.valueOf(genderName) }
            .getOrDefault(VoiceGender.FEMALE)

        val langCode = prefs[Keys.LANGUAGE_CODE] ?: PrimaryStoryLanguages.ENGLISH.code
        val langName = prefs[Keys.LANGUAGE_NAME] ?: PrimaryStoryLanguages.ENGLISH.englishName
        val speed = (prefs[Keys.VOICE_SPEED] ?: 1.0f).coerceIn(0.6f, 1.8f)

        UserSettings(
            autoPlayNext = prefs[Keys.AUTO_PLAY_NEXT] ?: true,
            startMuted = prefs[Keys.START_MUTED] ?: false,
            loopStory = prefs[Keys.LOOP_STORY] ?: false,
            videoQuality = quality,
            selectedLanguageCode = langCode,
            selectedLanguageName = langName,
            voiceGender = gender,
            voiceSpeed = speed
        )
    }

    suspend fun setAutoPlayNext(enabled: Boolean) {
        context.tokkorDataStore.edit { it[Keys.AUTO_PLAY_NEXT] = enabled }
    }

    suspend fun setStartMuted(muted: Boolean) {
        context.tokkorDataStore.edit { it[Keys.START_MUTED] = muted }
    }

    suspend fun setLoopStory(loop: Boolean) {
        context.tokkorDataStore.edit { it[Keys.LOOP_STORY] = loop }
    }

    suspend fun setVideoQuality(quality: VideoQuality) {
        context.tokkorDataStore.edit { it[Keys.VIDEO_QUALITY] = quality.name }
    }

    suspend fun setLanguage(language: StoryLanguageOption) {
        context.tokkorDataStore.edit {
            it[Keys.LANGUAGE_CODE] = language.code
            it[Keys.LANGUAGE_NAME] = language.englishName
        }
    }

    suspend fun setVoiceGender(gender: VoiceGender) {
        context.tokkorDataStore.edit { it[Keys.VOICE_GENDER] = gender.name }
    }

    suspend fun setVoiceSpeed(speed: Float) {
        context.tokkorDataStore.edit { it[Keys.VOICE_SPEED] = speed.coerceIn(0.6f, 1.8f) }
    }
}
