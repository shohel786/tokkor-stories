package com.example.data.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.data.model.PrimaryStoryLanguages
import com.example.data.model.Story
import com.example.data.model.StoryLanguageOption
import com.example.data.model.VoiceGender
import com.example.data.sample.StoryLocalization
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Locale

enum class NarrationPlaybackState {
    IDLE,
    PLAYING,
    PAUSED,
    COMPLETED,
    ERROR
}

enum class LanguageSupportStatus {
    SUPPORTED,
    MISSING_VOICE_DATA_FALLBACK,
    UNSUPPORTED_FALLBACK
}

data class VoiceNarrationState(
    val isEngineReady: Boolean = false,
    val engineUnavailable: Boolean = false,
    val activeStoryId: String? = null,
    val activeStoryTitle: String = "",
    val segments: List<String> = emptyList(),
    val currentSegmentIndex: Int = 0,
    val playbackState: NarrationPlaybackState = NarrationPlaybackState.IDLE,
    val selectedLanguage: StoryLanguageOption = PrimaryStoryLanguages.ENGLISH,
    val voiceGender: VoiceGender = VoiceGender.FEMALE,
    val speechSpeed: Float = 1.0f,
    val activeVoiceName: String? = null,
    val languageSupportStatus: LanguageSupportStatus = LanguageSupportStatus.SUPPORTED,
    val statusNotice: String? = null,
    val otherSupportedLanguages: List<StoryLanguageOption> = emptyList()
)

class VoiceNarrationManager(context: Context) : TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var activeStoryRef: Story? = null

    private val _state = MutableStateFlow(VoiceNarrationState())
    val state: StateFlow<VoiceNarrationState> = _state.asStateFlow()

    init {
        tts = runCatching { TextToSpeech(appContext, this) }.getOrNull()
        if (tts == null) {
            _state.update {
                it.copy(
                    isEngineReady = false,
                    engineUnavailable = true,
                    statusNotice = "Text-to-Speech engine is unavailable on this device."
                )
            }
        }
    }

    override fun onInit(status: Int) {
        val engine = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            _state.update {
                it.copy(
                    isEngineReady = false,
                    engineUnavailable = true,
                    statusNotice = "Unable to initialize device Text-to-Speech engine."
                )
            }
            return
        }

        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit

            override fun onDone(utteranceId: String?) {
                val expectedPrefix = "tokkor_seg_"
                if (utteranceId == null || !utteranceId.startsWith(expectedPrefix)) return
                val finishedIdx = utteranceId.removePrefix(expectedPrefix).toIntOrNull() ?: return

                val currentState = _state.value
                if (currentState.playbackState != NarrationPlaybackState.PLAYING) return

                val nextIdx = finishedIdx + 1
                if (nextIdx < currentState.segments.size) {
                    _state.update { it.copy(currentSegmentIndex = nextIdx) }
                    speakSegment(nextIdx)
                } else {
                    _state.update {
                        it.copy(
                            playbackState = NarrationPlaybackState.COMPLETED,
                            currentSegmentIndex = (currentState.segments.size - 1).coerceAtLeast(0)
                        )
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handleTtsPlaybackError()
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                handleTtsPlaybackError()
            }
        })

        val discoveredOtherLanguages = discoverOtherDeviceLanguages(engine)
        _state.update {
            it.copy(
                isEngineReady = true,
                engineUnavailable = false,
                otherSupportedLanguages = discoveredOtherLanguages
            )
        }
        applyVoiceConfiguration(
            language = _state.value.selectedLanguage,
            gender = _state.value.voiceGender,
            speed = _state.value.speechSpeed
        )
    }

    private fun handleTtsPlaybackError() {
        _state.update {
            it.copy(
                playbackState = NarrationPlaybackState.ERROR,
                statusNotice = "Voice playback encountered an audio error for this language."
            )
        }
    }

    private fun discoverOtherDeviceLanguages(engine: TextToSpeech): List<StoryLanguageOption> {
        val primaryCodes = PrimaryStoryLanguages.all.map { it.code.lowercase(Locale.US) }.toSet()
        val locales = runCatching { engine.availableLanguages.orEmpty() }
            .getOrDefault(emptySet())
            .ifEmpty {
                runCatching { engine.voices?.map { it.locale }.orEmpty().toSet() }
                    .getOrDefault(emptySet())
            }

        return locales
            .filter { locale ->
                val baseLang = locale.language.lowercase(Locale.US)
                baseLang.isNotBlank() && baseLang !in primaryCodes
            }
            .distinctBy { it.language.lowercase(Locale.US) }
            .map { locale ->
                val tag = locale.toLanguageTag()
                PrimaryStoryLanguages.fromTagOrDefault(tag)
            }
            .sortedBy { it.englishName }
    }

    fun updatePreferences(
        language: StoryLanguageOption,
        gender: VoiceGender,
        speed: Float
    ) {
        val prev = _state.value
        val languageChanged = prev.selectedLanguage.code != language.code
        val voiceOrSpeedChanged = prev.voiceGender != gender || prev.speechSpeed != speed

        _state.update {
            it.copy(
                selectedLanguage = language,
                voiceGender = gender,
                speechSpeed = speed
            )
        }

        if (_state.value.isEngineReady) {
            applyVoiceConfiguration(language, gender, speed)
        }

        val activeStory = activeStoryRef
        if (activeStory != null && languageChanged) {
            val localized = StoryLocalization.getLocalizedContent(activeStory, language)
            val newSegments = StoryLocalization.splitSentences(localized.narrationScript)
            val wasPlaying = prev.playbackState == NarrationPlaybackState.PLAYING
            tts?.stop()
            _state.update {
                it.copy(
                    activeStoryTitle = localized.localizedTitle,
                    segments = newSegments,
                    currentSegmentIndex = 0,
                    playbackState = if (wasPlaying) NarrationPlaybackState.PLAYING else NarrationPlaybackState.IDLE
                )
            }
            if (wasPlaying) {
                speakSegment(0)
            }
        } else if (activeStory != null && voiceOrSpeedChanged && prev.playbackState == NarrationPlaybackState.PLAYING) {
            tts?.stop()
            speakSegment(_state.value.currentSegmentIndex)
        }
    }

    fun prepareStory(story: Story) {
        activeStoryRef = story
        val lang = _state.value.selectedLanguage
        val localized = StoryLocalization.getLocalizedContent(story, lang)
        val segments = StoryLocalization.splitSentences(localized.narrationScript)

        if (_state.value.activeStoryId != story.id) {
            tts?.stop()
            _state.update {
                it.copy(
                    activeStoryId = story.id,
                    activeStoryTitle = localized.localizedTitle,
                    segments = segments,
                    currentSegmentIndex = 0,
                    playbackState = NarrationPlaybackState.IDLE
                )
            }
        } else {
            _state.update {
                it.copy(
                    activeStoryTitle = localized.localizedTitle,
                    segments = segments
                )
            }
        }
    }

    fun playStory(story: Story) {
        prepareStory(story)
        if (!_state.value.isEngineReady) {
            _state.update {
                it.copy(
                    playbackState = NarrationPlaybackState.ERROR,
                    statusNotice = it.statusNotice ?: "Voice engine is still initializing."
                )
            }
            return
        }
        applyVoiceConfiguration(
            _state.value.selectedLanguage,
            _state.value.voiceGender,
            _state.value.speechSpeed
        )
        _state.update {
            it.copy(
                currentSegmentIndex = 0,
                playbackState = NarrationPlaybackState.PLAYING
            )
        }
        speakSegment(0)
    }

    fun pause() {
        if (_state.value.playbackState == NarrationPlaybackState.PLAYING) {
            tts?.stop()
            _state.update { it.copy(playbackState = NarrationPlaybackState.PAUSED) }
        }
    }

    fun resume() {
        val current = _state.value
        if (!_state.value.isEngineReady) return
        val story = activeStoryRef ?: return
        if (current.segments.isEmpty()) {
            playStory(story)
            return
        }
        val resumeIdx = if (current.playbackState == NarrationPlaybackState.COMPLETED) {
            0
        } else {
            current.currentSegmentIndex.coerceIn(0, current.segments.lastIndex)
        }
        applyVoiceConfiguration(current.selectedLanguage, current.voiceGender, current.speechSpeed)
        _state.update {
            it.copy(
                currentSegmentIndex = resumeIdx,
                playbackState = NarrationPlaybackState.PLAYING
            )
        }
        speakSegment(resumeIdx)
    }

    fun stop() {
        tts?.stop()
        _state.update {
            it.copy(
                playbackState = NarrationPlaybackState.IDLE,
                currentSegmentIndex = 0
            )
        }
    }

    private fun speakSegment(index: Int) {
        val engine = tts ?: return
        val segments = _state.value.segments
        if (index !in segments.indices) return

        val text = segments[index]
        val params = Bundle()
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, "tokkor_seg_$index")
    }

    private fun applyVoiceConfiguration(
        language: StoryLanguageOption,
        gender: VoiceGender,
        speed: Float
    ) {
        val engine = tts ?: return
        engine.setSpeechRate(speed.coerceIn(0.6f, 1.8f))

        val candidateLocales = buildCandidateLocales(language)
        var chosenLocale: Locale? = null
        var bestResult = TextToSpeech.LANG_NOT_SUPPORTED

        for (candidate in candidateLocales) {
            val availability = runCatching { engine.isLanguageAvailable(candidate) }
                .getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)
            if (availability >= TextToSpeech.LANG_AVAILABLE) {
                chosenLocale = candidate
                bestResult = availability
                break
            } else if (availability == TextToSpeech.LANG_MISSING_DATA && chosenLocale == null) {
                chosenLocale = candidate
                bestResult = availability
            }
        }

        val targetLocale = chosenLocale ?: Locale.US
        val setLangResult = runCatching { engine.setLanguage(targetLocale) }
            .getOrDefault(TextToSpeech.LANG_NOT_SUPPORTED)

        val supportStatus: LanguageSupportStatus
        val notice: String?

        if (setLangResult < TextToSpeech.LANG_AVAILABLE) {
            runCatching { engine.setLanguage(Locale.US) }
            supportStatus = if (bestResult == TextToSpeech.LANG_MISSING_DATA) {
                LanguageSupportStatus.MISSING_VOICE_DATA_FALLBACK
            } else {
                LanguageSupportStatus.UNSUPPORTED_FALLBACK
            }
            notice = "Voice pack for ${language.englishName} is not installed on this device; using graceful fallback voice."
        } else {
            supportStatus = LanguageSupportStatus.SUPPORTED
            notice = null
        }

        val matchingVoice = selectVoiceForGender(
            engine = engine,
            locale = if (supportStatus == LanguageSupportStatus.SUPPORTED) targetLocale else Locale.US,
            gender = gender
        )

        if (matchingVoice != null) {
            runCatching { engine.voice = matchingVoice }
            // Reset pitch to natural 1.0 when a real matching voice is selected
            engine.setPitch(1.0f)
        } else {
            // Subtle pitch differentiation if device only ships a single generic voice
            engine.setPitch(if (gender == VoiceGender.MALE) 0.88f else 1.05f)
        }

        _state.update {
            it.copy(
                activeVoiceName = matchingVoice?.name,
                languageSupportStatus = supportStatus,
                statusNotice = notice
            )
        }
    }

    private fun buildCandidateLocales(language: StoryLanguageOption): List<Locale> {
        val base = language.code.lowercase(Locale.US).substringBefore('-')
        val extras = when (base) {
            "bn" -> listOf(Locale("bn", "BD"), Locale("bn", "IN"), Locale("bn"))
            "ar" -> listOf(Locale("ar", "SA"), Locale("ar", "EG"), Locale("ar"))
            "hi" -> listOf(Locale("hi", "IN"), Locale("hi"))
            "zh" -> listOf(Locale.SIMPLIFIED_CHINESE, Locale.TRADITIONAL_CHINESE, Locale.CHINESE)
            "ru" -> listOf(Locale("ru", "RU"), Locale("ru"))
            "en" -> listOf(Locale.US, Locale.UK, Locale.ENGLISH)
            else -> listOf(language.toLocale(), Locale(base))
        }
        return (listOf(language.toLocale()) + extras).distinct()
    }

    private fun selectVoiceForGender(
        engine: TextToSpeech,
        locale: Locale,
        gender: VoiceGender
    ): Voice? {
        val voices = runCatching { engine.voices }.getOrNull()?.toList().orEmpty()
        if (voices.isEmpty()) return null

        val languageMatches = voices.filter {
            it.locale.language.equals(locale.language, ignoreCase = true)
        }
        if (languageMatches.isEmpty()) return null

        val genderScored = languageMatches.sortedByDescending { voice ->
            var score = 0
            if (voice.locale.country.equals(locale.country, ignoreCase = true)) score += 4
            if (!voice.isNetworkConnectionRequired) score += 3

            val lowerName = voice.name.lowercase(Locale.US)
            val featureText = voice.features.joinToString(" ").lowercase(Locale.US)
            val combined = "$lowerName $featureText"

            val looksFemale = combined.contains("female") ||
                combined.contains("-f-") ||
                combined.contains("_f_") ||
                combined.contains("sfg") ||
                combined.contains("tpf") ||
                combined.contains("x-sfb") ||
                combined.contains("#female")
            val looksMale = combined.contains("male") && !combined.contains("female") ||
                combined.contains("-m-") ||
                combined.contains("_m_") ||
                combined.contains("iom") ||
                combined.contains("tpd") ||
                combined.contains("#male")

            when (gender) {
                VoiceGender.FEMALE -> if (looksFemale) score += 10 else if (looksMale) score -= 5
                VoiceGender.MALE -> if (looksMale) score += 10 else if (looksFemale) score -= 5
            }
            score
        }

        return genderScored.firstOrNull()
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
