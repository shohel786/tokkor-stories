package com.example.data.model

import androidx.annotation.DrawableRes
import java.util.Locale

enum class StoryCategory(
    val displayName: String,
    val tagline: String
) {
    MYSTERY("Mystery", "Shadows, clues & midnight turns"),
    SCI_FI("Sci-Fi", "Distant stars & quiet futures"),
    ROMANCE("Romance", "Fleeting glances & golden vows"),
    THRILLER("Thriller", "Heartbeat tension in 60 seconds"),
    FOLKLORE("Folklore", "Ancient lanterns & whispered myths"),
    DRAMA("Drama", "Raw human moments after dark")
}

enum class VideoQuality(val label: String, val description: String) {
    AUTO("Auto", "Adapts smoothly to your connection"),
    HIGH("HD 1080p", "Crispest cinema detail"),
    DATA_SAVER("Data Saver", "Faster loading on mobile networks")
}

enum class VoiceGender(val label: String) {
    FEMALE("Female"),
    MALE("Male")
}

data class StoryLanguageOption(
    val code: String,
    val englishName: String,
    val nativeName: String,
    val bcp47Tag: String,
    val isRtl: Boolean = false,
    val isPrimary: Boolean = true
) {
    val shortBadge: String
        get() = code.substringBefore('-').uppercase(Locale.US)

    fun toLocale(): Locale = Locale.forLanguageTag(bcp47Tag)
}

object PrimaryStoryLanguages {
    val ENGLISH = StoryLanguageOption(
        code = "en",
        englishName = "English",
        nativeName = "English",
        bcp47Tag = "en-US",
        isRtl = false
    )
    val BENGALI = StoryLanguageOption(
        code = "bn",
        englishName = "Bengali",
        nativeName = "বাংলা",
        bcp47Tag = "bn-BD",
        isRtl = false
    )
    val ARABIC = StoryLanguageOption(
        code = "ar",
        englishName = "Arabic",
        nativeName = "العربية",
        bcp47Tag = "ar-SA",
        isRtl = true
    )
    val HINDI = StoryLanguageOption(
        code = "hi",
        englishName = "Hindi",
        nativeName = "हिन्दी",
        bcp47Tag = "hi-IN",
        isRtl = false
    )
    val CHINESE = StoryLanguageOption(
        code = "zh",
        englishName = "Chinese",
        nativeName = "中文",
        bcp47Tag = "zh-CN",
        isRtl = false
    )
    val RUSSIAN = StoryLanguageOption(
        code = "ru",
        englishName = "Russian",
        nativeName = "Русский",
        bcp47Tag = "ru-RU",
        isRtl = false
    )

    val all: List<StoryLanguageOption> = listOf(
        BENGALI,
        ENGLISH,
        ARABIC,
        HINDI,
        CHINESE,
        RUSSIAN
    )

    fun findByCode(code: String): StoryLanguageOption? {
        val base = code.lowercase(Locale.US).substringBefore('-')
        return all.firstOrNull {
            it.code.equals(code, ignoreCase = true) ||
                it.code.equals(base, ignoreCase = true)
        }
    }

    fun fromTagOrDefault(code: String, fallbackName: String = ""): StoryLanguageOption {
        findByCode(code)?.let { return it }
        val locale = Locale.forLanguageTag(code)
        val lang = locale.language.ifBlank { code }
        val rtl = lang.equals("ar", ignoreCase = true) ||
            lang.equals("he", ignoreCase = true) ||
            lang.equals("iw", ignoreCase = true) ||
            lang.equals("fa", ignoreCase = true) ||
            lang.equals("ur", ignoreCase = true)
        val displayEng = locale.getDisplayLanguage(Locale.ENGLISH)
            .replaceFirstChar { it.uppercase(Locale.ENGLISH) }
            .ifBlank { fallbackName.ifBlank { code.uppercase(Locale.US) } }
        val displayNative = locale.getDisplayName(locale)
            .replaceFirstChar { it.uppercase(locale) }
            .ifBlank { displayEng }
        return StoryLanguageOption(
            code = code,
            englishName = displayEng,
            nativeName = displayNative,
            bcp47Tag = locale.toLanguageTag(),
            isRtl = rtl,
            isPrimary = false
        )
    }
}

data class Story(
    val id: String,
    val title: String,
    val author: String,
    val category: StoryCategory,
    val durationSeconds: Int,
    val synopsis: String,
    val moodTag: String,
    val isFeatured: Boolean,
    @DrawableRes val coverResId: Int,
    val videoUrl: String,
    val clipStartMs: Long = 0L,
    val clipEndMs: Long = 45_000L,
    val accentHex: Long = 0xFF7B4DFF
) {
    val formattedDuration: String
        get() {
            val mins = durationSeconds / 60
            val secs = durationSeconds % 60
            return "$mins:${secs.toString().padStart(2, '0')}"
        }
}

data class UserSettings(
    val autoPlayNext: Boolean = true,
    val startMuted: Boolean = false,
    val loopStory: Boolean = false,
    val videoQuality: VideoQuality = VideoQuality.AUTO,
    val selectedLanguageCode: String = PrimaryStoryLanguages.ENGLISH.code,
    val selectedLanguageName: String = PrimaryStoryLanguages.ENGLISH.englishName,
    val voiceGender: VoiceGender = VoiceGender.FEMALE,
    val voiceSpeed: Float = 1.0f
) {
    val selectedLanguage: StoryLanguageOption
        get() = PrimaryStoryLanguages.fromTagOrDefault(selectedLanguageCode, selectedLanguageName)
}
