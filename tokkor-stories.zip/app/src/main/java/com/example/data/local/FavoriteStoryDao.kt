package com.example.data.local

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "favorite_stories")
data class FavoriteStoryEntity(
    @PrimaryKey val storyId: String,
    val savedAtEpochMs: Long = System.currentTimeMillis()
)

@Dao
interface FavoriteStoryDao {
    @Query("SELECT storyId FROM favorite_stories ORDER BY savedAtEpochMs DESC")
    fun observeFavoriteIds(): Flow<List<String>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(favorite: FavoriteStoryEntity)

    @Query("DELETE FROM favorite_stories WHERE storyId = :storyId")
    suspend fun removeFavorite(storyId: String)

    @Query("DELETE FROM favorite_stories")
    suspend fun clearAllFavorites()
}
