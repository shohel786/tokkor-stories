package com.example.data.sample

import com.example.data.model.Story
import com.example.data.model.StoryLanguageOption
import java.util.Locale

data class LocalizedStoryContent(
    val localizedTitle: String,
    val narrationScript: String,
    val isFallbackLanguageScript: Boolean = false
)

/**
 * Provides full multilingual narration scripts and localized story titles for
 * Bengali, English, Arabic (RTL), Hindi, Chinese, and Russian, with graceful
 * English script fallback when a user picks any additional device TTS language.
 */
object StoryLocalization {

    private val scripts: Map<String, Map<String, LocalizedStoryContent>> = mapOf(
        "story_01" to mapOf(
            "en" to LocalizedStoryContent(
                "The Last Carriage at 00:47",
                "At forty-seven minutes past midnight, the express slowed over the stone viaduct. Inside the empty rear carriage, a gilded pocket watch began ticking backward on velvet seats. Each chime peeled away a forgotten winter, until the conductor's lantern revealed who had left the watch behind."
            ),
            "bn" to LocalizedStoryContent(
                "রাত ১২:৪৭-এর শেষ বগি",
                "রাত বারোটা সাতচল্লিশে পাথরের সেতুর ওপর দিয়ে রাতের এক্সপ্রেস ধীর হয়ে এল। ফাঁকা শেষ বগির মখমলের আসনে একটি সোনালি পকেট ঘড়ি উল্টো দিকে টিকটিক করে চলতে শুরু করল। প্রতিটি ঘণ্টাধ্বনি যেন একটি হারানো শীতের রাত ফিরিয়ে আনছিল, যতক্ষণ না গার্ডের লণ্ঠনের আলোয় ঘড়িটির আসল মালিকের পরিচয় ভেসে উঠল।"
            ),
            "ar" to LocalizedStoryContent(
                "العربة الأخيرة في تمام ٠٠:٤٧",
                "عند الساعة الثانية عشرة وسبعٍ وأربعين دقيقة بعد منتصف الليل، تباطأ القطار الليلي فوق الجسر الحجري. داخل العربة الخلفية الفارغة، بدأت ساعة جيب مذهّبة تدقّ إلى الوراء على المقعد المخملي. ومع كل رنّة، كان ضباب الذكريات ينقشع حتى كشف مصباح المراقب سرّ صاحبها الغامض."
            ),
            "hi" to LocalizedStoryContent(
                "रात 00:47 का आखिरी डिब्बा",
                "आधी रात के सैंतालीस मिनट बाद, पत्थर के पुल पर तेज़ रफ़्तार ट्रेन धीमी हो गई। खाली आखिरी डिब्बे की मखमली सीट पर रखी एक सुनहरी जेब घड़ी उल्टी दिशा में टिक-टिक करने लगी। हर धड़कन के साथ एक भूली हुई सर्दी लौट आई, जब तक कि कंडक्टर की लालटेन ने असली मुसाफ़िर का राज़ नहीं खोला।"
            ),
            "zh" to LocalizedStoryContent(
                "零点四十七分的末节车厢",
                "午夜零点四十七分，夜班列车缓缓驶过雾气弥漫的石桥。在空无一人的末节车厢天鹅绒座椅上，一只镀金怀表突然开始倒着走。每一声滴答都揭开一段被遗忘的冬夜往事，直到列车长的提灯照亮了怀表真正的主人。"
            ),
            "ru" to LocalizedStoryContent(
                "Последний вагон в 00:47",
                "В сорок семь минут за полночь ночной экспресс замедлил ход на каменном виадуке. В пустом последнем вагоне на бархатном сиденье золотые карманные часы вдруг пошли в обратную сторону. Каждый удар возвращал забытую зиму, пока фонарь проводника не открыл тайну их владельца."
            )
        ),
        "story_02" to mapOf(
            "en" to LocalizedStoryContent(
                "Astrolabe of Silent Seas",
                "By trembling candlelight, the captain aligned the brass astrolabe with the winter crescent moon. Beneath the silent harbor fog, ancient stone spires rose softly from dark indigo waters. Those who followed the golden coordinates discovered an island written out of every human map."
            ),
            "bn" to LocalizedStoryContent(
                "নীরব সাগরের অ্যাস্ট্রোল্যাব",
                "কাঁপা মোমবাতির আলোয় নাবিক তাঁর পিতলের অ্যাস্ট্রোল্যাবটি শীতের বাঁকা চাঁদের সাথে মেলালেন। নিস্তব্ধ বন্দরের কুয়াশার নিচে গাঢ় নীল জলরাশি ভেদ করে জেগে উঠল প্রাচীন পাথরের চূড়া। সোনালি দিকনির্দেশনা অনুসরণ করে তারা খুঁজে পেল মানচিত্রের বাইরের এক অজানা দ্বীপ।"
            ),
            "ar" to LocalizedStoryContent(
                "أسطرلاب البحار الصامتة",
                "على ضوء الشموع الخافت، وجّه القبطان الأسطرلاب النحاسي نحو هلال الشتاء الفضي. تحت ضباب الميناء الساكن، ارتفعت أبراج حجرية عتيقة من أعماق المياه الداكنة. ومن اتبع الإحداثيات الذهبية اكتشف جزيرةً لم تُرسم في أيّ خريطة بشرية."
            ),
            "hi" to LocalizedStoryContent(
                "खामोश समंदर का एस्ट्रोलैब",
                "काँपती मोमबत्ती की रोशनी में कप्तान ने पीतल के एस्ट्रोलैब को सर्दियों के चाँद की सीध में रखा। शांत बंदरगाह के कोहरे के नीचे गहरे नीले पानी से प्राचीन पत्थर की मीनारें उभर आईं। सुनहरे निशानों का पीछा करने वालों को हर नक्शे से गायब एक अनोखा द्वीप मिल गया।"
            ),
            "zh" to LocalizedStoryContent(
                "寂静之海的星盘",
                "在摇曳的烛光下，船长将黄铜星盘对准冬夜的弯月。寂静港湾的迷雾之下，古老的石塔从深蓝海面缓缓升起。顺着金色星标前行的人，终究找到了那座从世界地图上消失的岛屿。"
            ),
            "ru" to LocalizedStoryContent(
                "Астролябия тихих морей",
                "При дрожащем свете свечи капитан навёл латунную астролябию на зимний полумесяц. Под тихим туманом гавани из тёмных вод поднялись древние каменные шпили. Те, кто последовал за золотыми координатами, открыли остров, стёртый со всех карт мира."
            )
        ),
        "story_03" to mapOf(
            "en" to LocalizedStoryContent(
                "Lanterns on Wet Cobblestone",
                "Golden paper lanterns shimmered across the rain-washed cobblestones after midnight. Beneath a cedar awning, two strangers traded folded letters neither had been brave enough to send. Before the downpour eased, one shared umbrella turned a quiet street into a beginning."
            ),
            "bn" to LocalizedStoryContent(
                "ভেজা পাথরে লণ্ঠনের আলো",
                "মধ্যরাতের বৃষ্টির পর ভেজা পাথুরে রাস্তায় ঝিলমিল করে উঠল সোনালি কাগজের লণ্ঠন। দেবদারু ছাউনির নিচে দাঁড়িয়ে দুই অচেনা মানুষ বিনিময় করল দুটি ভাঁজ করা চিঠি, যা তারা কখনো পাঠাতে সাহস পায়নি। বৃষ্টি থামার আগেই একটি ছাতা নিঃশব্দ গলিকে বদলে দিল নতুন শুরুতে।"
            ),
            "ar" to LocalizedStoryContent(
                "فوانيس على الحجارة المبتلّة",
                "تلالأت الفوانيس الورقية الذهبية فوق الحجارة المبلّلة بالمطر بعد منتصف الليل. تحت مظلّة خشبية دافئة، تبادل غريبان رسالتين مطويّتين لم يجرؤ أيّ منهما على إرسالهما. وقبل أن يهدأ المطر، حوّلت مظلّة واحدة ذلك الزقاق الصامت إلى بداية جديدة."
            ),
            "hi" to LocalizedStoryContent(
                "भीगी गलियों में लालटेन",
                "आधी रात की बारिश के बाद भीगी पथरीली सड़क पर सुनहरी लालटेनें चमक उठीं। लकड़ी के छज्जे के नीचे दो अजनबियों ने वे मुड़े हुए खत साझा किए, जिन्हें भेजने की हिम्मत वे कभी न जुटा सके। बारिश थमने से पहले एक साझा छतरी ने उस शांत गली को एक नई शुरुआत बना दिया।"
            ),
            "zh" to LocalizedStoryContent(
                "雨夜石板路上的灯笼",
                "午夜雨后，金色的纸灯笼在湿润的石板路上倒映出微光。在雪松屋檐下，两位陌生人交换了各自一直不敢寄出的信件。雨势未歇之时，一把共撑的伞让静谧小巷化作故事的起点。"
            ),
            "ru" to LocalizedStoryContent(
                "Фонари на мокрой мостовой",
                "После полуночного ливня золотые бумажные фонари задрожали в лужах на брусчатке. Под кедровым навесом двое незнакомцев обменялись сложенными письмами, которые так и не решились отправить. И прежде чем дождь утих, один зонт превратил тихую улицу в начало истории."
            )
        ),
        "story_04" to mapOf(
            "en" to LocalizedStoryContent(
                "Orbit 94: Echoes in Amber",
                "High above Saturn's golden rings, Relay Station Ninety-Four drifted in total silence. Then a warm human voice crackled across the receiver, timestamped thirty years in the future. Listening closely, Commander Hale recognized his own daughter's laugh echoing through the stars."
            ),
            "bn" to LocalizedStoryContent(
                "অরবিট ৯৪: সোনালি প্রতিধ্বনি",
                "শনি গ্রহের সোনালি বলয়ের ওপরে নীরবে ভেসে ছিল রিলে স্টেশন চুরানব্বই। হঠাৎ রিসিভারে ভেসে এল এক উষ্ণ মানুষের কণ্ঠ, যার সময়চিহ্ন লেখা ছিল ত্রিশ বছর ভবিষ্যতের। মন দিয়ে শুনে কমান্ডার হেল তারাদের মাঝে নিজের মেয়ের হাসি চিনতে পারলেন।"
            ),
            "ar" to LocalizedStoryContent(
                "المدار ٩٤: أصداء العنبر",
                "فوق حلقات زحل الذهبية، كانت محطة الإرسال الرابعة والتسعون تسبح في صمتٍ عميق. وفجأة تردّد صوتٌ بشري دافئ عبر جهاز الاستقبال، يحمل تاريخاً بعد ثلاثين عاماً في المستقبل. وعندما أنصت القائد هيل، تعرّف على ضحكة ابنته تتردّد بين النجوم."
            ),
            "hi" to LocalizedStoryContent(
                "ऑर्बिट 94: सुनहरी गूँज",
                "शनि के सुनहरे छल्लों के ऊपर रिले स्टेशन चौरानवे गहरे सन्नाटे में तैर रहा था। तभी रिसीवर पर एक जानी-पहचानी इंसानी आवाज़ गूँजी, जिस पर तीस साल आगे के भविष्य की तारीख थी। ध्यान से सुनने पर कमांडर हेल ने तारों के बीच अपनी ही बेटी की हँसी पहचान ली।"
            ),
            "zh" to LocalizedStoryContent(
                "九十四号轨道：琥珀回声",
                "在土星金色光环之上，九十四号中继站静静漂浮在深空里。忽然，接收器里传来一段温暖的人声，时间戳竟来自三十年后的未来。指挥官黑尔屏息聆听，认出了那是女儿在星海间回荡的笑声。"
            ),
            "ru" to LocalizedStoryContent(
                "Орбита 94: Янтарное эхо",
                "Высоко над золотыми кольцами Сатурна ретранслятор девяносто четыре дрейфовал в безмолвии. Внезапно в приёмнике прозвучал тёплый голос с отметкой времени на тридцать лет вперёд. Вслушавшись, командир Хейл узнал смех собственной дочери среди звёзд."
            )
        ),
        "story_05" to mapOf(
            "en" to LocalizedStoryContent(
                "Velvet Cipher",
                "Sixty seconds remained before the museum vault locked down for the night. Shining an amber penlight over the canvas, the curator spotted invisible ink woven into the brushstrokes. The forged masterpiece was never meant to be stolen—it was a coded warning."
            ),
            "bn" to LocalizedStoryContent(
                "মখমলের গুপ্তসংকেত",
                "রাতের জন্য জাদুঘরের ভল্ট বন্ধ হতে আর মাত্র ষাট সেকেন্ড বাকি। চিত্রকর্মের ওপর অ্যাম্বার আলো ফেলতেই কিউরেটর তুলির আঁচড়ে লুকানো অদৃশ্য কালি দেখতে পেলেন। নকল ছবিটি চুরি করার জন্য তৈরি হয়নি—এটি ছিল এক গোপন সতর্কবার্তা।"
            ),
            "ar" to LocalizedStoryContent(
                "شيفرة المخمل",
                "بقيت ستّون ثانية فقط قبل أن تُغلق خزينة المتحف طوال الليل. وحين سلّطت أمينة المعرض ضوءاً كهرمانياً على اللوحة، لمحت حبراً خفيّاً بين ضربات الفرشاة. لم تكن اللوحة المزوّرة للسرقة قطّ، بل كانت رسالة تحذير مشفّرة."
            ),
            "hi" to LocalizedStoryContent(
                "मखमली कूटलिपि",
                "रात के लिए संग्रहालय का वॉल्ट बंद होने में बस साठ सेकंड बाकी थे। कैनवास पर हल्की सुनहरी रोशनी डालते ही क्यूरेटर को रंगों के बीच छिपी अदृश्य स्याही दिख गई। वह नकली पेंटिंग चोरी के लिए नहीं थी—वह एक गुप्त चेतावनी थी।"
            ),
            "zh" to LocalizedStoryContent(
                "天鹅绒密文",
                "距离博物馆金库夜间封锁只剩最后六十秒。策展人将琥珀色微光照向画布，竟在笔触间发现了隐形墨水。那幅赝品从来不是为了盗窃而画，而是一封加密的警讯。"
            ),
            "ru" to LocalizedStoryContent(
                "Бархатный шифр",
                "До ночной блокировки музейного хранилища оставалось шестьдесят секунд. Наведя янтарный фонарик на холст, хранительница заметила невидимые чернила среди мазков. Поддельный шедевр создали не для кражи — это было зашифрованное предупреждение."
            )
        ),
        "story_06" to mapOf(
            "en" to LocalizedStoryContent(
                "The Stationmaster's Ledger",
                "After forty years on duty, Arthur opened his worn leather ledger for one final night shift. Outside the frost-rimmed window, a silver locomotive glided silently into Platform Zero. Its passengers carried tickets stamped with the names of promises kept."
            ),
            "bn" to LocalizedStoryContent(
                "স্টেশনমাস্টারের খাতা",
                "চল্লিশ বছরের দায়িত্ব শেষে আর্থার শেষ রাতের ডিউটির জন্য তাঁর পুরোনো চামড়ার খাতা খুললেন। তুষারঢাকা জানালার বাইরে নিঃশব্দে শূন্য নম্বর প্ল্যাটফর্মে এসে থামল এক রুপালি ইঞ্জিন। এর যাত্রীদের টিকিটে লেখা ছিল পূরণ হওয়া সব প্রতিশ্রুতির নাম।"
            ),
            "ar" to LocalizedStoryContent(
                "سجلّ ناظر المحطة",
                "بعد أربعين عاماً من العمل، فتح آرثر سجلّه الجلدي العتيق لنوبته الليلية الأخيرة. خلف النافذة المكسوّة بالصقيع، انزلقت قاطرة فضية بصمت نحو الرصيف صفر. كان ركّابها يحملون تذاكر خُتمت عليها أسماء الوعود التي أُوفي بها."
            ),
            "hi" to LocalizedStoryContent(
                "स्टेशनमास्टर की बही",
                "चालीस साल की सेवा के बाद आर्थर ने अपनी आखिरी रात की ड्यूटी के लिए चमड़े की पुरानी बही खोली। कोहरे से ढकी खिड़की के बाहर प्लेटफॉर्म शून्य पर एक रूपहला इंजन चुपचाप आ रुका। उसके यात्रियों के पास निभाए गए वादों के नाम वाले टिकट थे।"
            ),
            "zh" to LocalizedStoryContent(
                "站长的手账",
                "坚守岗位四十年后，亚瑟翻开磨损的皮面手账，迎来最后一班夜岗。覆满薄霜的窗外，一列银色机车悄然滑入零号站台。车上的旅人手持车票，上面印着一个个兑现的诺言。"
            ),
            "ru" to LocalizedStoryContent(
                "Журнал начальника станции",
                "После сорока лет службы Артур открыл потёртый кожаный журнал в свою последнюю ночную смену. За морозным окном к нулевой платформе бесшумно подошёл серебристый локомотив. У его пассажиров в руках были билеты с именами сдержанных обещаний."
            )
        ),
        "story_07" to mapOf(
            "en" to LocalizedStoryContent(
                "Paper Moon Over Kyoto",
                "Along the dark canal, paper lanterns floated like captured fireflies beneath the willow branches. Every lantern carried an unspoken wish whispered at dusk. As midnight struck, one golden lantern slipped its tether and rose gently toward the constellations."
            ),
            "bn" to LocalizedStoryContent(
                "কিয়োটোর আকাশে কাগজের চাঁদ",
                "অন্ধকার খালের ধারে উইলো গাছের নিচে জোনাকির মতো ভেসে ছিল কাগজের লণ্ঠনগুলো। প্রতিটি লণ্ঠনে বাঁধা ছিল গোধূলিতে ফিসফিস করে বলা একটি অপূর্ণ ইচ্ছা। মধ্যরাত বাজতেই একটি সোনালি লণ্ঠন বাঁধন ছিঁড়ে ধীরে ধীরে নক্ষত্রের দিকে ভেসে উঠল।"
            ),
            "ar" to LocalizedStoryContent(
                "قمرٌ من ورق فوق كيوتو",
                "على امتداد القناة الهادئة، طفت الفوانيس الورقية كاليراعات المضيئة تحت أغصان الصفصاف. كان كلّ فانوس يحمل أمنيةً هامسة أُطلقت عند الغسق. ومع دقّات منتصف الليل، تحرّر فانوسٌ ذهبي وارتفع برفق نحو النجوم."
            ),
            "hi" to LocalizedStoryContent(
                "क्योटो के ऊपर कागज़ का चाँद",
                "अँधेरी नहर के किनारे विलो के पेड़ों के नीचे कागज़ की लालटेनें जुगनुओं की तरह तैर रही थीं। हर लालटेन में शाम के समय फुसफुसाई गई एक अनकही ख्वाहिश बंधी थी। आधी रात होते ही एक सुनहरी लालटेन डोर से छूटकर धीरे-धीरे तारों की ओर उड़ चली।"
            ),
            "zh" to LocalizedStoryContent(
                "京都纸月",
                "在幽暗的运河畔，纸灯笼宛如流萤般在垂柳下轻晃。每一盏灯里都寄托着黄昏时分低语的心愿。午夜钟声敲响时，一盏金色灯笼悄然挣脱丝线，缓缓升向星辰。"
            ),
            "ru" to LocalizedStoryContent(
                "Бумажная луна над Киото",
                "Вдоль тёмного канала под ветвями ив бумажные фонарики плыли, словно пойманные светлячки. Каждый из них хранил невысказанное желание, прошептанное на закате. В полночь один золотой фонарик оторвался и тихо взмыл к созвездиям."
            )
        ),
        "story_08" to mapOf(
            "en" to LocalizedStoryContent(
                "Chronograph of Glass",
                "In a quiet workshop lit by blue sparks, Sienna polished a fractured crystal watch lens. Looking through the glass, she saw raindrops rising five seconds before they fell. Even five seconds was enough to change a stranger's fate at the crosswalk."
            ),
            "bn" to LocalizedStoryContent(
                "কাচের ক্রোনোগ্রাফ",
                "নীল স্ফুলিঙ্গের আলোয় আলোকিত নীরব কর্মশালায় সিয়েনা একটি ফাটা স্ফটিকের ঘড়ির কাচ ঘষে পরিষ্কার করলেন। সেই কাচের ভেতর দিয়ে তিনি বৃষ্টির ফোঁটা পড়ার পাঁচ সেকেন্ড আগেই তা দেখতে পেলেন। রাস্তার মোড়ে একজন পথচারীর ভাগ্য বদলে দিতে সেই পাঁচ সেকেন্ডই ছিল যথেষ্ট।"
            ),
            "ar" to LocalizedStoryContent(
                "كرونوغراف الزجاج",
                "في ورشةٍ هادئة تضيئها شرارات زرقاء، صقلت سيينا عدسة ساعةٍ من الكريستال المشقوق. وعندما نظرت عبر الزجاج، رأت قطرات المطر قبل سقوطها بخمس ثوانٍ. وكانت خمس ثوانٍ فقط كافيةً لتغيير مصير عابرٍ عند ممرّ المشاة."
            ),
            "hi" to LocalizedStoryContent(
                "काँच का क्रोनोग्राफ",
                "नीली चिंगारियों से रोशन शांत कार्यशाला में सिएना ने एक तड़के हुए क्रिस्टल घड़ी के लेंस को तराशा। उस काँच के पार उसे बारिश की बूँदें गिरने से पाँच सेकंड पहले ही दिखाई दे गईं। चौराहे पर एक अनजान की किस्मत बदलने के लिए वे पाँच सेकंड ही काफी थे।"
            ),
            "zh" to LocalizedStoryContent(
                "玻璃计时仪",
                "在蓝色火花点亮的静谧工坊里，西耶娜擦亮了一枚带裂纹的水晶表镜。透过镜片，她看见雨滴在落下前五秒的模样。仅仅五秒，便足以在路口改写一位陌生人的命运。"
            ),
            "ru" to LocalizedStoryContent(
                "Хронограф из стекла",
                "В тихой мастерской под голубыми искрами Сиенна отполировала треснувшее хрустальное стекло часов. Взглянув сквозь него, она увидела капли дождя за пять секунд до падения. Даже пяти секунд хватило, чтобы изменить судьбу прохожего на перекрёстке."
            )
        ),
        "story_09" to mapOf(
            "en" to LocalizedStoryContent(
                "Signal at Milepost Seven",
                "Through freezing mountain sleet, an amber semaphore blinked from the abandoned tower at Milepost Seven. Devon decoded the rhythmic flashes from memory: wait three minutes, do not cross the bridge. Moments later, the canyon thundered beneath an avalanche."
            ),
            "bn" to LocalizedStoryContent(
                "মাইলপোস্ট সাতে সংকেত",
                "পাহাড়ি হিমেল বৃষ্টির ভেতর পরিত্যক্ত সাত নম্বর টাওয়ার থেকে জ্বলে-নিভে উঠল এক অ্যাম্বার সংকেতবাতি। ডেভন স্মৃতি থেকে আলোটির মর্স কোড পড়ে ফেললেন: তিন মিনিট অপেক্ষা করো, সেতু পার হয়ো না। কয়েক মুহূর্ত পরই তুষারধসের গর্জনে কেঁপে উঠল গিরিখাত।"
            ),
            "ar" to LocalizedStoryContent(
                "إشارة عند المعلم السابع",
                "وسط صقيع الجبال القارس، ومض مصباحٌ كهرماني من البرج المهجور عند المعلم السابع. فكّ ديفون شفرة الوميض من ذاكرته: انتظر ثلاث دقائق، ولا تعبر الجسر. وبعد لحظات، دوّى صوت انهيارٍ ثلجي في أرجاء الوادي."
            ),
            "hi" to LocalizedStoryContent(
                "मील के पत्थर सात पर संकेत",
                "बर्फीली पहाड़ी हवा के बीच सातवें मील के सूने टॉवर से एक सुनहरा सिग्नल चमका। डेवन ने याददाश्त से उस मोर्स कोड को पढ़ा: तीन मिनट रुको, पुल पार मत करना। कुछ ही पल बाद गहरी घाटी में हिमस्खलन की गूँज उठी।"
            ),
            "zh" to LocalizedStoryContent(
                "七号里程碑的信号",
                "穿过刺骨的山间雨雪，七号里程碑的废弃信号塔亮起了琥珀色灯光。德文凭记忆破译出闪烁的电码：等待三分钟，切勿过桥。片刻之后，山谷间响起了雪崩的轰鸣。"
            ),
            "ru" to LocalizedStoryContent(
                "Сигнал у седьмого столба",
                "Сквозь горный ледяной дождь с заброшенной башни у седьмого столба мигнул янтарный семафор. Девон по памяти расшифровал вспышки: жди три минуты, не переходи мост. Через мгновение ущелье содрогнулось от лавины."
            )
        ),
        "story_10" to mapOf(
            "en" to LocalizedStoryContent(
                "Two Tickets to Dawn",
                "First light painted Platform Four in soft copper and navy blue. Instead of boarding alone, Claire pressed a second coastal ticket into his palm. The whistle blew, and together they chose the morning train without looking back."
            ),
            "bn" to LocalizedStoryContent(
                "ভোরের দুটি টিকিট",
                "ভোরের প্রথম আলোয় চার নম্বর প্ল্যাটফর্ম রাঙা হয়ে উঠল তামাটে আর নীল রঙে। একা ট্রেনে না উঠে ক্লেয়ার তাঁর হাতে তুলে দিলেন উপকূলগামী দ্বিতীয় টিকিটটি। হুইসেল বাজতেই পেছনে না তাকিয়ে তারা দুজনে উঠে পড়লেন সকালের ট্রেনে।"
            ),
            "ar" to LocalizedStoryContent(
                "تذكرتان نحو الفجر",
                "لوّن نور الفجر الأوّل الرصيف الرابع بدرجات النحاس الدافئ والأزرق الداكن. وبدلاً من الصعود وحدها، وضعت كلير تذكرةً ثانية إلى الساحل في راحة يده. دوّت صافرة القطار، فاختارا معاً قطار الصباح دون الالتفات إلى الوراء."
            ),
            "hi" to LocalizedStoryContent(
                "भोर के दो टिकट",
                "सुबह की पहली किरण ने प्लेटफॉर्म चार को तांबे और गहरे नीले रंग में रंग दिया। अकेले ट्रेन में चढ़ने के बजाय क्लेयर ने समुद्र तट का दूसरा टिकट उसकी हथेली पर रख दिया। सीटी बजी, और बिना पीछे देखे दोनों सुबह की ट्रेन में सवार हो गए।"
            ),
            "zh" to LocalizedStoryContent(
                "通往黎明的两张车票",
                "晨曦将四号站台染成温柔的铜金与深蓝。克莱尔没有独自登车，而是把另一张前往海岸的车票放进他掌心。汽笛长鸣，两人并肩登上晨间列车，不再回头。"
            ),
            "ru" to LocalizedStoryContent(
                "Два билета до рассвета",
                "Первые лучи окрасили четвёртую платформу в мягкую медь и глубокую синеву. Вместо того чтобы сесть в вагон одной, Клэр вложила ему в ладонь второй билет к побережью. Прозвучал свисток, и они вместе шагнули в утренний поезд, не оглядываясь назад."
            )
        )
    )

    fun getLocalizedContent(story: Story, language: StoryLanguageOption): LocalizedStoryContent {
        val storyMap = scripts[story.id].orEmpty()
        val baseCode = language.code.lowercase(Locale.US).substringBefore('-')
        val exact = storyMap[baseCode]
        if (exact != null) return exact

        val fallback = storyMap["en"] ?: LocalizedStoryContent(
            localizedTitle = story.title,
            narrationScript = story.synopsis
        )
        return fallback.copy(isFallbackLanguageScript = baseCode != "en")
    }

    fun splitSentences(text: String): List<String> {
        val raw = text.split(Regex("(?<=[.!?।؟。！？])\\s*"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
        return if (raw.isEmpty()) listOf(text) else raw
    }
}
