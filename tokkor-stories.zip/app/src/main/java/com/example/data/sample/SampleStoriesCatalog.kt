package com.example.data.sample

import com.example.R
import com.example.data.model.Story
import com.example.data.model.StoryCategory

/**
 * Curated initial sample catalog of 30-60 second short video stories.
 * Uses reliable Google-hosted sample MP4 streams with ExoPlayer ClippingConfiguration
 * windows so each reel runs cleanly between 34 and 58 seconds.
 *
 * Replace or augment with a Firebase Firestore adapter via [RemoteStorySyncAdapter] in the future.
 */
object SampleStoriesCatalog {

    private const val STREAM_TEARS_OF_STEEL =
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
    private const val STREAM_SINTEL =
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
    private const val STREAM_ELEPHANTS_DREAM =
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"
    private const val STREAM_BIG_BUCK_BUNNY =
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
    private const val STREAM_SUBARU =
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4"
    private const val STREAM_BULLRUN =
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4"

    val stories: List<Story> = listOf(
        Story(
            id = "story_01",
            title = "The Last Carriage at 00:47",
            author = "Elena Vance",
            category = StoryCategory.MYSTERY,
            durationSeconds = 48,
            synopsis = "A lone passenger discovers a gilded pocket watch ticking backward as the midnight express crosses the misty stone viaduct.",
            moodTag = "Atmospheric • Noir",
            isFeatured = true,
            coverResId = R.drawable.img_story_midnight_train,
            videoUrl = STREAM_TEARS_OF_STEEL,
            clipStartMs = 38_000L,
            clipEndMs = 86_000L,
            accentHex = 0xFFD4AF37
        ),
        Story(
            id = "story_02",
            title = "Astrolabe of Silent Seas",
            author = "Julian Thorne",
            category = StoryCategory.FOLKLORE,
            durationSeconds = 54,
            synopsis = "When the brass astrolabe aligns with the winter crescent, an unmapped archipelago rises beneath the harbor fog.",
            moodTag = "Mythic • Candlelit",
            isFeatured = true,
            coverResId = R.drawable.img_story_brass_compass,
            videoUrl = STREAM_SINTEL,
            clipStartMs = 68_000L,
            clipEndMs = 122_000L,
            accentHex = 0xFFF3D578
        ),
        Story(
            id = "story_03",
            title = "Lanterns on Wet Cobblestone",
            author = "Mei-Ling Sato",
            category = StoryCategory.ROMANCE,
            durationSeconds = 42,
            synopsis = "Two strangers shelter beneath a cedar awning during an autumn downpour, trading handwritten letters meant for someone else.",
            moodTag = "Poetic • Warm Rain",
            isFeatured = true,
            coverResId = R.drawable.img_story_rain_lanterns,
            videoUrl = STREAM_ELEPHANTS_DREAM,
            clipStartMs = 30_000L,
            clipEndMs = 72_000L,
            accentHex = 0xFFE6B655
        ),
        Story(
            id = "story_04",
            title = "Orbit 94: Echoes in Amber",
            author = "Marcus K. Hale",
            category = StoryCategory.SCI_FI,
            durationSeconds = 56,
            synopsis = "Inside a quiet relay station above Saturn, an archival voice message arrives thirty years before it was ever recorded.",
            moodTag = "Deep Space • Wonder",
            isFeatured = false,
            coverResId = R.drawable.img_story_brass_compass,
            videoUrl = STREAM_TEARS_OF_STEEL,
            clipStartMs = 120_000L,
            clipEndMs = 176_000L,
            accentHex = 0xFF7CA7FF
        ),
        Story(
            id = "story_05",
            title = "Velvet Cipher",
            author = "Nadia Al-Mansoor",
            category = StoryCategory.THRILLER,
            durationSeconds = 39,
            synopsis = "Sixty seconds before the gallery vault seals for the night, the curator realizes the forged painting is actually a warning.",
            moodTag = "Suspense • High Stakes",
            isFeatured = false,
            coverResId = R.drawable.img_story_rain_lanterns,
            videoUrl = STREAM_BULLRUN,
            clipStartMs = 4_000L,
            clipEndMs = 43_000L,
            accentHex = 0xFFE05A6D
        ),
        Story(
            id = "story_06",
            title = "The Stationmaster's Ledger",
            author = "Arthur Pendelton",
            category = StoryCategory.DRAMA,
            durationSeconds = 51,
            synopsis = "On his final night shift after forty years, a retired conductor greets the one train that never appeared on any timetable.",
            moodTag = "Heartfelt • Reflective",
            isFeatured = false,
            coverResId = R.drawable.img_story_midnight_train,
            videoUrl = STREAM_SUBARU,
            clipStartMs = 5_000L,
            clipEndMs = 56_000L,
            accentHex = 0xFFD4AF37
        ),
        Story(
            id = "story_07",
            title = "Paper Moon Over Kyoto",
            author = "Haruki Mori",
            category = StoryCategory.FOLKLORE,
            durationSeconds = 45,
            synopsis = "Each paper lantern hung along the canal carries a forgotten promise—until one floats upward toward the stars.",
            moodTag = "Serene • Enchanted",
            isFeatured = false,
            coverResId = R.drawable.img_story_rain_lanterns,
            videoUrl = STREAM_BIG_BUCK_BUNNY,
            clipStartMs = 16_000L,
            clipEndMs = 61_000L,
            accentHex = 0xFFF3D578
        ),
        Story(
            id = "story_08",
            title = "Chronograph of Glass",
            author = "Sienna Brooks",
            category = StoryCategory.SCI_FI,
            durationSeconds = 36,
            synopsis = "A watchmaker repairs a cracked crystal lens that lets its wearer glimpse five seconds into tomorrow's dawn.",
            moodTag = "Sleek • Futurist",
            isFeatured = false,
            coverResId = R.drawable.img_story_brass_compass,
            videoUrl = STREAM_TEARS_OF_STEEL,
            clipStartMs = 200_000L,
            clipEndMs = 236_000L,
            accentHex = 0xFF8BB8FF
        ),
        Story(
            id = "story_09",
            title = "Signal at Milepost Seven",
            author = "Devon Sterling",
            category = StoryCategory.THRILLER,
            durationSeconds = 44,
            synopsis = "Through sleet and mountain pine, an amber semaphore lantern flashes Morse code from an abandoned signal tower.",
            moodTag = "Tense • Midnight",
            isFeatured = false,
            coverResId = R.drawable.img_story_midnight_train,
            videoUrl = STREAM_SINTEL,
            clipStartMs = 155_000L,
            clipEndMs = 199_000L,
            accentHex = 0xFFD4AF37
        ),
        Story(
            id = "story_10",
            title = "Two Tickets to Dawn",
            author = "Claire Moreau",
            category = StoryCategory.ROMANCE,
            durationSeconds = 58,
            synopsis = "At Platform 4 before sunrise, an unspoken farewell turns into a spontaneous journey across the northern coast.",
            moodTag = "Intimate • Golden Hour",
            isFeatured = false,
            coverResId = R.drawable.img_story_midnight_train,
            videoUrl = STREAM_BIG_BUCK_BUNNY,
            clipStartMs = 70_000L,
            clipEndMs = 128_000L,
            accentHex = 0xFFE6B655
        )
    )
}
