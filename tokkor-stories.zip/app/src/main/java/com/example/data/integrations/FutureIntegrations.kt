package com.example.data.integrations

import com.example.data.model.Story

/**
 * Architectural extension points preparing Tokkor Stories for future
 * Firebase Firestore / Remote Config and Google AdMob integrations
 * without requiring paid services, login, or external SDKs in v1.
 */
interface RemoteStoryCatalogProvider {
    val providerName: String
    val isRemoteConnected: Boolean
    suspend fun fetchLatestStories(): List<Story>
}

class LocalSampleCatalogProvider(
    private val sampleStories: List<Story>
) : RemoteStoryCatalogProvider {
    override val providerName: String = "Firebase Firestore (Ready)"
    override val isRemoteConnected: Boolean = false

    override suspend fun fetchLatestStories(): List<Story> = sampleStories
}

interface AdMonetizationAdapter {
    val engineName: String
    val isEnabled: Boolean
    fun preloadInterstitialIfReady()
}

class NoOpAdMonetizationAdapter : AdMonetizationAdapter {
    override val engineName: String = "Google AdMob (Ready)"
    override val isEnabled: Boolean = false

    override fun preloadInterstitialIfReady() {
        // Future AdMob interstitial/banner preload hook between story reels
    }
}
