package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [FavoriteStoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class TokkorDatabase : RoomDatabase() {
    abstract fun favoriteStoryDao(): FavoriteStoryDao

    companion object {
        @Volatile
        private var instance: TokkorDatabase? = null

        fun getInstance(context: Context): TokkorDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    TokkorDatabase::class.java,
                    "tokkor_stories_db"
                ).build().also { instance = it }
            }
        }
    }
}
