package com.example

import com.example.data.model.PrimaryStoryLanguages
import com.example.data.model.StoryCategory
import com.example.data.sample.SampleStoriesCatalog
import com.example.data.sample.StoryLocalization
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun sampleCatalog_meetsDurationAndCategoryRequirements() {
        val stories = SampleStoriesCatalog.stories
        assertTrue(stories.size >= 10)
        assertTrue(stories.any { it.isFeatured })
        assertTrue(stories.all { it.durationSeconds in 30..60 })
        assertEquals(StoryCategory.entries.size, stories.map { it.category }.distinct().size)
    }

    @Test
    fun sampleCatalog_formattedDurationMatchesSeconds() {
        val story = SampleStoriesCatalog.stories.first()
        assertEquals("0:48", story.formattedDuration)
    }

    @Test
    fun multilingualScripts_coverAllPrimaryLanguagesAndArabicRtl() {
        assertTrue(PrimaryStoryLanguages.ARABIC.isRtl)
        assertFalse(PrimaryStoryLanguages.ENGLISH.isRtl)
        assertFalse(PrimaryStoryLanguages.BENGALI.isRtl)

        SampleStoriesCatalog.stories.forEach { story ->
            PrimaryStoryLanguages.all.forEach { lang ->
                val content = StoryLocalization.getLocalizedContent(story, lang)
                assertTrue(content.localizedTitle.isNotBlank())
                assertTrue(content.narrationScript.isNotBlank())
                assertFalse(content.isFallbackLanguageScript)
                val sentences = StoryLocalization.splitSentences(content.narrationScript)
                assertTrue(sentences.size >= 2)
            }
        }
    }

    @Test
    fun unsupportedLanguage_fallsBackGracefullyToEnglishScript() {
        val story = SampleStoriesCatalog.stories.first()
        val spanish = PrimaryStoryLanguages.fromTagOrDefault("es-ES", "Spanish")
        val content = StoryLocalization.getLocalizedContent(story, spanish)
        assertTrue(content.isFallbackLanguageScript)
        assertTrue(content.narrationScript.isNotBlank())
    }
}
