package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.StoryCategory
import com.example.data.sample.SampleStoriesCatalog
import com.example.ui.viewmodel.PlaylistContext
import com.example.ui.viewmodel.SearchQuickFilter
import com.example.ui.viewmodel.TokkorViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches Tokkor Stories`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Tokkor Stories", appName)
    }

    @Test
    fun `sample catalog stories are 30 to 60 seconds and include featured`() {
        val stories = SampleStoriesCatalog.stories
        assertTrue(stories.size >= 10)
        assertTrue(stories.any { it.isFeatured })
        assertTrue(stories.all { it.durationSeconds in 30..60 })
        assertEquals(StoryCategory.entries.size, stories.map { it.category }.distinct().size)
    }

    @Test
    fun `viewModel filters search results and resolves category playlists`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = TokkorViewModel(app)

        val initial = viewModel.uiState.first { it.allStories.isNotEmpty() }
        assertTrue(initial.featuredStories.isNotEmpty())

        viewModel.updateSearchQuery("Astrolabe")
        val afterSearch = viewModel.uiState.first { it.searchQuery == "Astrolabe" }
        assertEquals(1, afterSearch.searchResults.size)
        assertEquals("story_02", afterSearch.searchResults.first().id)

        viewModel.setSearchQuickFilter(SearchQuickFilter.UNDER_45_SEC)
        viewModel.updateSearchQuery("")
        val quickFiltered = viewModel.uiState.first {
            it.searchQuery.isEmpty() && it.searchQuickFilter == SearchQuickFilter.UNDER_45_SEC
        }
        assertTrue(quickFiltered.searchResults.all { it.durationSeconds <= 45 })

        val mysteryPlaylist = viewModel.resolvePlaylist(
            contextType = PlaylistContext.CATEGORY,
            categoryName = StoryCategory.MYSTERY.name
        )
        assertTrue(mysteryPlaylist.isNotEmpty())
        assertTrue(mysteryPlaylist.all { it.category == StoryCategory.MYSTERY })
    }
}
